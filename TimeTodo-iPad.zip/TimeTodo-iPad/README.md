# TimeTodo · iPad 原生版（SwiftUI）

这是把安卓版 TimeTodo 复刻成 **iOS/iPadOS 原生 App** 的完整 Xcode 工程。
iPad 横屏时是「侧边栏 + 主区」大屏布局，竖屏或 iPhone 上自动变成单列。

> **重要前提**：iOS 应用无法由 APK 转换而来，必须用 Mac 上的 Xcode 编译、再用苹果证书签名后才能装到 iPad。本仓库提供的就是那个可以直接编译的工程。

---

## 一、功能对照（与安卓版一致）

| 功能 | 安卓版行为 | iPad 版行为 |
|---|---|---|
| 时段划分 | 21:40→次日11:40 上午；11:40–17:40 下午；17:40–21:40 晚上 | ✅ 完全相同（`TimeRule`） |
| 跨天 | 21:40 起算「次日」 | ✅ 相同，今日页/日历页同步切换 |
| 上午显示文案 | `07:00 – 11:40`（切换节点仍是 21:40） | ✅ 相同 |
| 今日待办 | 三段文字输入即存、当前时段高亮 | ✅ 三张卡片 + 当前徽章，30 秒自动跟随时钟 |
| 未来待办 | 一段不随时段切换的文字 | ✅ 相同 |
| 日历预约 | 月历 + 某天三段；写过文字显示「文本式」，否则显示任务列表 | ✅ 相同，另有全天事项分组 |
| 重复规则 | 每天/每周/每月（按 X 日或第 N 个周 X）/每年 + 间隔 + 截止 | ✅ 判定逻辑逐条复刻自 `TodoFilter` |
| 时间轴 | 竖线 + 彩色节点串，标签左右交替，点节点编辑 | ✅ Canvas 绘制，同样的 8 色调色板 |
| 桌面小组件 | 5x2 预约小组件（左日历 + 右三段） | ✅ WidgetKit 小组件（中/大两种尺寸），数据经 App Group 共享 |

数据保存在 App 沙盒 `Application Support/TimeTodo/store.json`，一个文件存全部内容。

## 二、拿到可安装的 .ipa（两条路，任选一条）

> 源码就是软件本体，缺的只有「编译」这一步。下面两条路都能产出 `TimeTodo-unsigned.ipa`，
> 之后用你手上的签名（Sideloadly / 爱思助手 / 企业签名服务）签一下就能装进 iPad。

### 方案 A：没有 Mac —— 用 GitHub 网页版 Actions 编译（推荐，全程只点鼠标）

> 详细图文步骤见 **`网页版编译指引.html`**（双击用浏览器打开，里面有可一键复制的工作流内容）。

**先说计费**（避免额度莫名其妙用完）：macOS 机器按 **10 倍**扣额度。
Public 仓库 **完全免费、不限次数**；Private 仓库每月 2000 分钟 ≈ 200 分钟 macOS ≈ 60 次构建（一次约 3 分钟）。
源码里没有密钥，建议建 **Public** 仓库。

1. **建仓库**：打开 `github.com/new` → Repository name 填 `TimeTodo-iPad` → 选 **Public** →
   **不要**勾选 Add a README / .gitignore / license（保持空仓库）→ 点 **Create repository**。
2. **上传工程**：在空仓库页面点 **Add file → Upload files**，把 `TimeTodo-iPad.zip` 直接拖进去
   → 点绿色 **Commit changes**。
   （工作流已做容错：仓库里只有 zip 时，构建时自动解压并自动找到工程目录；
   想上传文件夹也可以，但要进入 `TimeTodo-iPad` 内部全选再拖，别把外层文件夹一起拖。）
3. **建工作流**：**Add file → Create new file**，文件名输入
   `.github/workflows/build-ipa.yml`（斜杠会自动建目录），把仓库里同名文件的内容整个粘贴进去
   → **Commit changes**。
   > 网页上传会跳过 `.github` 这种隐藏文件夹，所以这一步必须手动建。
   > 提交的这一刻就会**自动开始编译**（工作流监听了 main 分支的 push），不用再点 Run workflow。
4. **看进度**：点仓库顶部 **Actions** → 左侧 **Build unsigned IPA** → 最新的那条记录。
   黄点＝运行中，绿勾＝成功，红叉＝失败（点进去看哪一步红了）。
5. **下载 ipa**：点进那次运行 → 拉到页面最底部 **Artifacts** → 点 `TimeTodo-unsigned-ipa`
   → 得到一个 zip → 解压出 **`TimeTodo-unsigned.ipa`**（Artifacts 必须登录 GitHub 才能下载，
   且保留 30 天，过期要重跑一次）。
6. **签名安装**（三选一）：
   - **Windows**：Sideloadly（免费 Apple ID 也能签，7 天有效）或爱思助手；
   - **Mac**：Sideloadly / Xcode 的 Devices and Simulators / Apple Configurator；
   - **企业签名 / 超级签**：直接把 `TimeTodo-unsigned.ipa` 交给签名服务商。

**手动重跑**：Actions → 左侧 Build unsigned IPA → 右上 **Run workflow** → 分支选 `main` → 绿色 **Run workflow**。
（改了代码后重新上传 zip 提交，也会自动触发。）

**常见卡点**：

| 现象 | 原因 / 处理 |
|---|---|
| Actions 页面提示要启用工作流 | 点 **I understand my workflows, go ahead and enable them** |
| 看不到 Artifacts | 要先点进某一次具体运行，它在页面最底部 |
| 日志报「找不到 TimeTodo.xcodeproj」 | 上传的不是本工程 / 压缩包改名了；重新上传 `TimeTodo-iPad.zip` |
| Build 步骤红叉 | 点开该步骤看最后几十行报错，把报错发我即可 |
| 额度几分钟就没了 | 仓库是 Private，且 macOS 按 10 倍计费；改 Public 或减少重跑 |

### 方案 B：有 Mac —— 双击脚本或 Xcode

- **最快**：双击 `build-ipa.command`，它会在工程目录和桌面各生成一份 `TimeTodo-unsigned.ipa`。
- **或者**：双击 `TimeTodo.xcodeproj` → 顶部选 iPad 模拟器按 `▶` 先看效果；
  连真机则登录 Apple ID（Xcode → Settings → Accounts），
  在 Signing & Capabilities 里选个人团队，设备选 iPad，按 `▶` 直接装（免费账号 7 天过期，重按一次即可）。


## 三、桌面小组件（WidgetKit）

**先回答一个常见问题：网页版（PWA）在 iPad 上做不到桌面小组件。**
iPadOS 的小组件只向原生 App（WidgetKit 扩展）开放，Safari「添加到主屏幕」的网页最多只能
全屏独立运行，永远进不了小组件列表。所以要做小组件，只有原生这一条路——本工程已经做好了：

### 它是怎么工作的

- 工程里有 **两个 target**：主 App `TimeTodo` + 小组件扩展 `TimeTodoWidget`（Bundle ID `com.timetodo.ipad.widget`）。
- App 每次保存数据，都会把预约/文本写进 **App Group 共享容器**（`group.com.timetodo.ipad`），
  并让小组件时间线重画。
- 小组件拿到的是**原始数据**，它自己按 `TimeRule`（21:40 / 11:40 / 17:40 三个边界）排好
  时间线：到点由系统自动换页，**不依赖 App 是否在运行、不用后台刷新**。
- 提供中尺寸（三段纯文本，当前时段高亮）和大尺寸（字号更大、每段最多 4 行）两种。
- 没有数据时显示「打开 TimeTodo 写一句，这里就会自动同步」，不会一片空白。

### 添加到桌面

装好 App 后：长按桌面空白处 → 左上角 **+** → 搜「TimeTodo」→ 选 **今日三段** → 拖到桌面。
在小组件上**点一下**任意区域即可直接打开 App。

### 手写批注（墨迹覆盖在打字内容上层）

先说明一个系统限制：**小组件里不能直接落笔**。WidgetKit 的小组件是只读快照，
不接受自由绘制，Apple Pencil 在桌面小组件上也无法书写——这是 iOS 的规则，任何 App 都绕不过。

所以这里做的是最接近的闭环：

1. 在小组件上**点「上午 / 下午 / 晚上」某一行** → 打开 App 的手写页；
2. 手写页里，底层用浅灰显示这一段已经打好的文字，上层是可书写的透明画布
   （手指或 Apple Pencil 都能写，可选黑/蓝/红、三档粗细）；
3. 点「完成」→ 笔画被渲染成**透明背景 PNG**，存进 App Group；
4. 小组件立刻重画，把这张 PNG **叠在该行文字的上层**。

### 笔 / 橡皮 / 撤销（改错字不用整段重写）

工具条上是「笔」「橡皮」两个胶囊按钮，右边是 ↩︎ 撤销、↪︎ 重做、清空：

| 操作 | 行为 |
|---|---|
| 笔 | 写字，可选 黑 / 蓝 / 红 三色、细中粗三档 |
| 橡皮 | **整笔擦除**：划到哪一笔就删掉那一笔（抬一次笔算一笔），可选小/中/大三档橡皮 |
| ↩︎ 撤销 | 一层层退回刚才的书写或擦除，最多 40 步 |
| ↪︎ 重做 | 撤销过头了往回走 |
| 清空 | 全清，但**也进历史**，误点能撤回 |

所以改一两个错字，用橡皮点掉那几笔就行，不用清空再重写；万一擦多了，按 ↩︎ 立刻回退。

> 为什么是「整笔」擦而不是擦掉半个笔画：PencilKit 的位图橡皮在导出 PNG 时有失效风险
> （小组件上可能出现已擦掉的内容又冒出来），整笔擦除的渲染结果 100% 确定，
> 书写/擦除后的 PNG 与屏幕上看到的完全一致。

其他细节：

- App 内也能手写：「今日待办」每张卡片右上角有一个 ✎ 按钮，进的是同一个页面。
- 再次进入手写页会加载上次的笔画，可以继续写；点「清空」并保存即可全部擦掉。
- 书写过程中不会每落一笔就重绘界面（只有工具/按钮状态变化才刷新），Pencil 延迟更低。
- 想先看看手感：用浏览器打开 `手写页预览.html`，可以在纸上真的写、真的擦，逻辑与 App 内一致。
- 有手写的那一行，小组件右侧会显示一个小铅笔图标。
- 墨迹按「日期 + 时段」分开存：`yyyy-MM-dd-morning.png` / `.drawing`，切换日期不会串。
- 位置是按比例缩放的：手写画板固定 640×200 逻辑尺寸，小组件里等比缩放到该行。
  如果某行文字特别多、行高变大，墨迹会居中缩放，可能有轻微偏移。

### ⚠️ 签名要求（重要）

小组件和 App 之间共享数据需要 **App Groups 能力**（工程里已通过 entitlements 配好）：

| 你的签名方式 | App Groups | 小组件效果 |
|---|---|---|
| 付费开发者账号（688 元/年）、企业签名、超级签 | ✅ 支持 | 完整可用 |
| **免费 Apple ID**（个人 7 天签名） | ❌ 不支持 | App 能装能跑，小组件装上后显示「还没有内容」 |

用免费 Apple ID 时，Sideloadly 可能在签名时报 App Groups 相关错误；
即使装上，小组件也读不到数据。想要小组件可用，请使用上表中的付费类签名。

### 如果签名服务要求改 App Group 名称

把这两个文件里的 `group.com.timetodo.ipad` 改成服务商指定的名称即可（两处要一致）：
`Shared/WidgetData.swift` 顶部的 `appGroup` 常量，以及两个 `.entitlements` 文件。

> 编译要求 **Xcode 15 或更高**（小组件背景用了 iOS 17 的 `containerBackground`，
> 已做旧系统兼容，但编译工具链需要 15+）。GitHub Actions 的 macos-14 机器自带 Xcode 15，可直接用。

## 四、文件结构

```
TimeTodo-iPad/
├─ TimeTodo.xcodeproj/          # Xcode 工程（App + 小组件扩展两个 target）
├─ .github/workflows/build-ipa.yml  # GitHub Actions：云端出未签名 ipa
├─ build-ipa.command            # Mac 上一键出 ipa
├─ project.yml                  # xcodegen 备用配置
├─ 界面预览.html                # 浏览器可打开的界面示意
├─ 小组件预览.html              # 浏览器可打开的小组件效果示意
├─ 手写页预览.html              # 浏览器可交互试写：笔 / 橡皮 / 撤销
├─ TimeTodo/                    # 主 App 源码（SwiftUI）
│   ├─ TimeTodoApp.swift        # 入口 + 根导航
│   ├─ RootView.swift           # 侧边栏 + 手写深链（timetodo://ink）
│   ├─ TodayView.swift          # 三段卡片 + 未来待办 + 手写入口
│   ├─ AppointmentView.swift    # 月历 + 当天详情 + 预约编辑弹窗
│   ├─ TimelineView.swift       # Canvas 时间轴 + 任务编辑
│   ├─ HandwritingView.swift    # PencilKit 手写页：笔/橡皮/撤销重做 + 渲染透明 PNG
│   ├─ Store.swift              # JSON 持久化（唯一数据入口）+ 小组件同步
│   ├─ Models.swift             # TimeRule / AppointmentItem / TimelineTask + 重复判定
│   ├─ Theme.swift              # 配色（与安卓版同源）与卡片样式
│   ├─ Info.plist               # 注册 timetodo:// URL scheme
│   ├─ TimeTodo.entitlements    # App Group 声明
│   └─ Assets.xcassets/         # 应用图标 + 主题色
├─ TimeTodoWidget/              # 小组件扩展源码
│   ├─ TimeTodoWidget.swift     # 时间线 + 中/大布局 + 墨迹叠加 + 行点击深链
│   ├─ Info.plist               # WidgetKit 扩展声明
│   └─ TimeTodoWidget.entitlements
└─ Shared/                      # 两个 target 共同编译的文件
    ├─ WidgetData.swift         # App Group 读写 + 数据快照 + 边界时间计算
    └─ InkStore.swift           # 手写墨迹的共享存储（PNG + PencilKit 数据）
```

## 五、拿到 ipa 之后怎么签

| 你手上的签名 | 操作 |
|---|---|
| Apple ID（免费或付费） | Sideloadly / 爱思助手：拖入 ipa，填 Apple ID，点 Start。免费账号 7 天有效 |
| 开发者证书（.p12 + .mobileprovision） | 在 Sideloadly 里选「Use Certificate」导入，或用 Xcode 直接签真机 |
| 企业签名 / 超级签服务 | 把 `TimeTodo-unsigned.ipa` 发给服务商，拿回已签名的 ipa 用网页/工具安装 |

> 注意：ipa 里现在包含两个组件——`TimeTodo.app` 和里面的
> `PlugIns/TimeTodoWidget.appex`，签名工具会一起重签，不用手动处理。

Bundle ID：主 App `com.timetodo.ipad`、小组件扩展 `com.timetodo.ipad.widget`。
若你的证书只允许特定 Bundle ID，把两个 target 的
`PRODUCT_BUNDLE_IDENTIFIER`（`project.pbxproj` 或 Xcode 的 Signing 页）一起改掉——
**扩展的 Bundle ID 必须以主 App 的为前缀**，否则装不上。


## 六、与安卓版的已知差异

- **提醒/闹钟字段只做存储与展示**：iOS 端尚未接入本地通知（UNUserNotificationCenter）。需要的话可以后续加上，字段（提前 5/10/30/60 分钟或准时）已保留。
- **小组件布局**：iPadOS 小组件只有固定的中/大尺寸，做不到安卓 5x2 那种「左日历 + 右三段」
  的自由比例；本版的小组件为「三段文本」形态，日历仍以 App 内为主。
- 两端数据互不相通（iOS 沙盒无法读取安卓 SharedPreferences），首次使用需重新录入。
