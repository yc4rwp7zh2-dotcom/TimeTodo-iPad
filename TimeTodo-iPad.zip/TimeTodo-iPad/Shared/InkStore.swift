import Foundation
import UIKit

/// 手写墨迹的共享存储。
///
/// 墨迹按「哪一天 + 哪个时段」分开存，放在 App Group 的共享容器里，
/// 这样主 App 画完、小组件立刻能读到。
///
/// 每个位置存两份：
/// - `<key>.png`     —— 透明背景的位图，给小组件直接叠加在文字上层用；
/// - `<key>.drawing` —— PencilKit 的笔画数据，回到 App 里可以继续修改。
enum InkStore {
    private static let folderName = "Ink"

    /// 共享容器下的 Ink 目录。
    static var directory: URL? {
        guard let base = FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: WidgetShared.appGroup) else {
            return nil
        }
        let dir = base.appendingPathComponent(folderName, isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    /// 稳定 key：2026-11-18-morning
    static func key(day: Date, period: TimePeriod) -> String {
        DateKey.string(from: day) + "-" + period.rawValue
    }

    static func imageURL(day: Date, period: TimePeriod) -> URL? {
        directory?.appendingPathComponent(key(day: day, period: period) + ".png")
    }

    static func drawingURL(day: Date, period: TimePeriod) -> URL? {
        directory?.appendingPathComponent(key(day: day, period: period) + ".drawing")
    }

    /// 小组件用：读这一格的手写图（没有就返回 nil）。
    static func image(day: Date, period: TimePeriod) -> UIImage? {
        guard let url = imageURL(day: day, period: period),
              FileManager.default.fileExists(atPath: url.path) else { return nil }
        return UIImage(contentsOfFile: url.path)
    }

    static func hasInk(day: Date, period: TimePeriod) -> Bool {
        guard let url = imageURL(day: day, period: period) else { return false }
        return FileManager.default.fileExists(atPath: url.path)
    }

    /// 保存渲染好的透明 PNG。
    @discardableResult
    static func saveImage(_ image: UIImage, day: Date, period: TimePeriod) -> Bool {
        guard let url = imageURL(day: day, period: period),
              let data = image.pngData() else { return false }
        do {
            try data.write(to: url, options: .atomic)
            return true
        } catch {
            return false
        }
    }

    static func saveDrawingData(_ data: Data, day: Date, period: TimePeriod) {
        guard let url = drawingURL(day: day, period: period) else { return }
        try? data.write(to: url, options: .atomic)
    }

    static func drawingData(day: Date, period: TimePeriod) -> Data? {
        guard let url = drawingURL(day: day, period: period) else { return nil }
        return try? Data(contentsOf: url)
    }

    /// 清空某一格的手写（连同位图和笔画数据）。
    static func clear(day: Date, period: TimePeriod) {
        if let png = imageURL(day: day, period: period) {
            try? FileManager.default.removeItem(at: png)
        }
        if let drw = drawingURL(day: day, period: period) {
            try? FileManager.default.removeItem(at: drw)
        }
    }

    /// 某个协议里要用到的「这一天有没有任何手写」，供列表/日历打点。
    static func hasAnyInk(day: Date) -> Bool {
        TimePeriod.allCases.contains { hasInk(day: day, period: $0) }
    }
}
