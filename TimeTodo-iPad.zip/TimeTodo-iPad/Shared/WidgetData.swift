import Foundation

/// 主 App 与小组件扩展共用的一份数据快照。
///
/// 两个 target 都会编译这个文件：
/// - 主 App 在每次保存后 `write(_:)` 一份到这里；
/// - 小组件扩展在刷新时间线时 `read()`，自己按 `TimeRule` 算出
///   此刻该显示哪一天、哪个时段。
///
/// 之所以让小组件自己算而不是让 App 把「结论」写进来：
/// 这样跨 11:40 / 17:40 / 21:40 三个边界时，即使 App 没启动过，
/// 小组件也能按时间线自己换到正确的页。
enum WidgetShared {
    /// 需要和两个 target 的 entitlements 里保持一致。
    /// 换账号签名时若 Bundle 前缀不同，改这一处即可。
    static let appGroup = "group.com.timetodo.ipad"
    static let storageKey = "com.timetodo.widget.data.v1"

    static var defaults: UserDefaults? {
        UserDefaults(suiteName: appGroup)
    }

    private static var encoder: JSONEncoder {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        return e
    }

    private static var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }

    static func write(_ data: WidgetData) {
        guard let defaults = defaults,
              let raw = try? encoder.encode(data) else { return }
        defaults.set(raw, forKey: storageKey)
    }

    static func read() -> WidgetData? {
        guard let defaults = defaults,
              let raw = defaults.data(forKey: storageKey),
              let data = try? decoder.decode(WidgetData.self, from: raw) else {
            return nil
        }
        return data
    }
}

/// 小组件需要的全部数据。故意做成扁平结构，避免两边模型互相耦合。
struct WidgetData: Codable {
    var appointments: [AppointmentItem] = []
    /// dayKey(2026-11-18) -> period.rawValue -> 正文
    var dayTexts: [String: [String: String]] = [:]
    /// 首页三段文字（旧字段，留给「今天」兜底显示）
    var periodTexts: [String: String] = [:]
    var updatedAt: Date = Date()

    /// 完全没有内容时（首次安装，或 App Group 拿不到权限），
    /// 小组件用来显示一行提示，而不是三行空白加横线。
    var isEmpty: Bool {
        appointments.isEmpty && dayTexts.isEmpty && periodTexts.isEmpty
    }

    /// 某天某时段在小组件里该显示的纯文本（没有就是空串）。
    func text(day: Date, period: TimePeriod) -> String {
        let key = DateKey.string(from: day)
        if let value = dayTexts[key]?[period.rawValue],
           !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return value
        }
        // 今天没写过「文本式」，退回首页那三段文字，避免小组件整片空白
        if Calendar.current.isDateInToday(day) {
            return periodTexts[period.rawValue] ?? ""
        }
        return ""
    }

    /// 某天某时段的预约条目（只取未完成的，最多 4 条给小组件排版用）。
    func items(day: Date, period: TimePeriod, limit: Int = 4) -> [String] {
        appointments
            .filter { !$0.allDay && $0.period == period && $0.matches(day: day) }
            .sorted { lhs, rhs in
                if lhs.done != rhs.done { return !lhs.done }
                return lhs.displayText < rhs.displayText
            }
            .prefix(limit)
            .map { $0.displayText }
    }

    func allDayItems(day: Date, limit: Int = 2) -> [String] {
        appointments
            .filter { $0.allDay && $0.matches(day: day) }
            .sorted { $0.displayText < $1.displayText }
            .prefix(limit)
            .map { $0.displayText }
    }

    /// 某天哪些时段有内容，给日历格子画小圆点。
    func dotPeriods(day: Date) -> [TimePeriod] {        let key = DateKey.string(from: day)
        var result: [TimePeriod] = []
        for period in TimePeriod.allCases {
            let hasItem = appointments.contains {
                !$0.allDay && $0.period == period && $0.matches(day: day)
            }
            let hasText = !(dayTexts[key]?[period.rawValue] ?? "").isEmpty
            if hasItem || hasText { result.append(period) }
        }
        return result
    }

    /// 小组件时间线要用的下一个边界时刻：11:40 / 17:40 / 21:40。
    static func nextBoundaries(after date: Date = Date(),
                               count: Int = 4,
                               calendar: Calendar = .current) -> [Date] {
        let minutes: [Int] = [TimeRule.afternoonStart,
                              TimeRule.eveningStart,
                              TimeRule.daySwitch]
        let startOfDay = calendar.startOfDay(for: date)
        var candidates: [Date] = []
        for offset in 0...2 {
            guard let day = calendar.date(byAdding: .day, value: offset, to: startOfDay) else { continue }
            for m in minutes {
                if let t = calendar.date(byAdding: .minute, value: m, to: day), t > date {
                    candidates.append(t)
                }
            }
        }
        return Array(candidates.sorted().prefix(count))
    }
}
