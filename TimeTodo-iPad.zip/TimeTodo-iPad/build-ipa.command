#!/bin/bash
# 在有 Mac 的机器上双击运行（或在终端执行 ./build-ipa.command），
# 直接在桌面上生成 TimeTodo-unsigned.ipa。
set -euo pipefail

cd "$(dirname "$0")"

echo "==> 清理旧产物"
rm -rf build Payload TimeTodo-unsigned.ipa

echo "==> 编译（关闭签名，稍后由签名工具处理）"
xcodebuild \
  -project TimeTodo.xcodeproj \
  -scheme TimeTodo \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  build

echo "==> 打包成 ipa"
mkdir -p Payload
cp -R build/Build/Products/Release-iphoneos/TimeTodo.app Payload/
rm -rf "Payload/TimeTodo.app/_CodeSignature" || true
# 小组件扩展也在包里，未签名包同样要去掉它的签名目录
rm -rf "Payload/TimeTodo.app/PlugIns/TimeTodoWidget.appex/_CodeSignature" || true
if [ -d "Payload/TimeTodo.app/PlugIns/TimeTodoWidget.appex" ]; then
  echo "  ✓ 已包含小组件扩展 TimeTodoWidget.appex"
else
  echo "  ! 警告：没找到 PlugIns/TimeTodoWidget.appex，桌面小组件可能不可用"
fi
zip -qr TimeTodo-unsigned.ipa Payload

OUT="$(pwd)/TimeTodo-unsigned.ipa"
cp "$OUT" "$HOME/Desktop/TimeTodo-unsigned.ipa" 2>/dev/null || true

echo ""
echo "完成：$OUT"
echo "（桌面也放了一份：~/Desktop/TimeTodo-unsigned.ipa）"
echo "接下来用 Sideloadly / 爱思助手 / 你的签名服务对这个 ipa 签名安装即可。"
