import WidgetKit
import SwiftUI
import UIKit

// MARK: - 时间线条目

struct PeriodEntry: TimelineEntry {
    let date: Date
    let data: WidgetData
    /// key = `InkStore.key(day:period:)`，value = 透明背景的手写墨迹图。
    var inks: [String: UIImage] = [:]

    /// 这个条目对应「哪一天」——21:40 之后算次日，与 App 内完全同口径。
    var day: Date { TimeRule.effectiveDay(now: date) }

    /// 这个条目对应「哪个时段」。
    var period: TimePeriod { TimeRule.period(for: date) }

    func ink(for period: TimePeriod) -> UIImage? {
        inks[InkStore.key(day: day, period: period)]
    }
}

// MARK: - Provider

struct PeriodProvider: TimelineProvider {
    func placeholder(in context: Context) -> PeriodEntry {
        PeriodEntry(date: Date(), data: Sample.data)
    }

    func getSnapshot(in context: Context, completion: @escaping (PeriodEntry) -> Void) {
        // 挂在小组件库里的预览，用示例数据，避免一片空白
        if context.isPreview {
            completion(PeriodEntry(date: Date(), data: Sample.data))
        } else {
            let data = WidgetShared.read() ?? Sample.data
            completion(makeEntry(date: Date(), data: data))
        }
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<PeriodEntry>) -> Void) {
        let data = WidgetShared.read() ?? WidgetData()
        let now = Date()

        var entries = [makeEntry(date: now, data: data)]
        // 在接下来几个时段边界上各排一个条目，让小组件到点自己换页。
        // 这是系统级的时间线切换，不依赖 App 运行、也不用后台刷新。
        for boundary in WidgetData.nextBoundaries(after: now, count: 4) {
            entries.append(makeEntry(date: boundary, data: data))
        }

        // 兜底：最后一个边界过去 3 分钟后再整体刷一次，顺便重读一次磁盘数据。
        let refresh = (entries.last?.date ?? now).addingTimeInterval(180)
        completion(Timeline(entries: entries, policy: .after(refresh)))
    }

    /// 每个条目把当时该显示的那一天的三张手写图预读好，
    /// 避免视图重建时反复读文件。
    private func makeEntry(date: Date, data: WidgetData) -> PeriodEntry {
        let day = TimeRule.effectiveDay(now: date)
        var inks: [String: UIImage] = [:]
        for period in TimePeriod.allCases {
            if let image = InkStore.image(day: day, period: period) {
                inks[InkStore.key(day: day, period: period)] = image
            }
        }
        return PeriodEntry(date: date, data: data, inks: inks)
    }
}

/// 小组件库里预览用的示例数据。
enum Sample {
    static var data: WidgetData {
        var d = WidgetData()
        d.periodTexts = [
            TimePeriod.morning.rawValue: "体检表交给医务室，顺便把课表贴到讲台上。",
            TimePeriod.afternoon.rawValue: "14:00 数学组集体备课\n批改第三单元练习",
            TimePeriod.evening.rawValue: "备课：第 26 课\n给小组件写明天的三段"
        ]
        return d
    }
}

// MARK: - 视图

struct PeriodWidgetView: View {
    @Environment(\.widgetFamily) private var family
    var entry: PeriodEntry

    private var isCompact: Bool { family == .systemMedium }

    private var dayTitle: String {
        let m = CalendarMath.month(of: entry.day)
        let d = CalendarMath.day(of: entry.day)
        let names = ["一", "二", "三", "四", "五", "六", "日"]
        let w = CalendarMath.isoWeekday(entry.day)
        return "\(m)月\(d)日 周\(names[max(0, min(6, w - 1))])"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: isCompact ? 5 : 7) {
            header

            if entry.data.isEmpty {
                emptyHint
            } else {
                ForEach(TimePeriod.allCases) { period in
                    periodRow(period)
                        .frame(maxHeight: .infinity, alignment: .top)
                }
            }
        }
        .padding(.horizontal, 11)
        .padding(.vertical, 9)
        .widgetBackground(Palette.background)
        // iOS 16 上多行 Link 不一定都生效，整块再挂一个兜底：
        // 点空白处至少能进「当前时段」的手写页。
        .widgetURL(inkURL(for: entry.period))
    }

    /// 没数据时的提示。多半是第一次装、还没打开过 App，
    /// 或者签名时 App Group 能力没带上（免费个人账号不支持）。
    private var emptyHint: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("还没有内容")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(Palette.title)
            Text("打开 TimeTodo 写一句，这里就会自动同步。")
                .font(.system(size: 10.5))
                .foregroundColor(Palette.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline, spacing: 6) {
            Text(dayTitle)
                .font(.system(size: isCompact ? 12.5 : 14, weight: .semibold))
                .foregroundColor(Palette.title)
            Text("· \(entry.period.displayName)")
                .font(.system(size: isCompact ? 10 : 11, weight: .medium))
                .foregroundColor(color(for: entry.period))
            Spacer(minLength: 0)
            Text(clock)
                .font(.system(size: 9.5, weight: .regular).monospacedDigit())
                .foregroundColor(Palette.secondary)
        }
    }

    private var clock: String {
        let c = Calendar.current.dateComponents([.hour, .minute], from: entry.date)
        return String(format: "%02d:%02d", c.hour ?? 0, c.minute ?? 0)
    }

    private func periodRow(_ period: TimePeriod) -> some View {
        let text = entry.data.text(day: entry.day, period: period)
        let items = entry.data.items(day: entry.day, period: period,
                                     limit: isCompact ? 2 : 3)
        let isCurrent = period == entry.period
        let ink = entry.ink(for: period)

        return Link(destination: inkURL(for: period)) {
            rowContent(period: period, text: text, items: items, isCurrent: isCurrent)
                // 手写墨迹盖在打字内容的上层。
                // 用 overlay 而不是 ZStack：图片不会参与布局，不会把行撑高。
                .overlay(alignment: .topLeading) {
                    if let ink {
                        Image(uiImage: ink)
                            .resizable()
                            .scaledToFit()
                            .allowsHitTesting(false)
                    }
                }
                .padding(.vertical, isCompact ? 3 : 5)
                .padding(.horizontal, 6)
                .background(
                    RoundedRectangle(cornerRadius: 7)
                        .fill(isCurrent ? color(for: period).opacity(0.09) : Color.clear)
                )
        }
    }

    private func rowContent(period: TimePeriod,
                            text: String,
                            items: [String],
                            isCurrent: Bool) -> some View {
        HStack(alignment: .top, spacing: 7) {
            RoundedRectangle(cornerRadius: 1.5)
                .fill(color(for: period).opacity(isCurrent ? 1 : 0.35))
                .frame(width: 3)

            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 5) {
                    Text(period.displayName)
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(color(for: period))
                    Text(period.timeRange)
                        .font(.system(size: 8.5))
                        .foregroundColor(Palette.secondary)
                    if isCurrent {
                        Text("当前")
                            .font(.system(size: 8, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 4)
                            .padding(.vertical, 1)
                            .background(Capsule().fill(color(for: period)))
                    }
                    Spacer(minLength: 0)
                    if entry.ink(for: period) != nil {
                        Image(systemName: "pencil.tip")
                            .font(.system(size: 8))
                            .foregroundColor(Palette.secondary)
                    }
                }

                if !text.isEmpty {
                    Text(text)
                        .font(.system(size: isCompact ? 10.5 : 12))
                        .foregroundColor(Palette.body)
                        .lineLimit(isCompact ? 2 : 4)
                        .fixedSize(horizontal: false, vertical: true)
                } else if !items.isEmpty {
                    Text(items.joined(separator: "　·　"))
                        .font(.system(size: isCompact ? 10.5 : 12))
                        .foregroundColor(Palette.body)
                        .lineLimit(isCompact ? 2 : 3)
                } else {
                    Text("—")
                        .font(.system(size: 10.5))
                        .foregroundColor(Palette.secondary.opacity(0.45))
                }
            }
        }
    }

    /// 点这一行 → 打开 App 的手写页，并带上日期与时段。
    private func inkURL(for period: TimePeriod) -> URL {
        var components = URLComponents()
        components.scheme = "timetodo"
        components.host = "ink"
        components.queryItems = [
            URLQueryItem(name: "day", value: DateKey.string(from: entry.day)),
            URLQueryItem(name: "period", value: period.rawValue)
        ]
        return components.url ?? URL(string: "timetodo://ink")!
    }

    private func color(for period: TimePeriod) -> Color {
        switch period {
        case .morning: return Palette.morning
        case .afternoon: return Palette.afternoon
        case .evening: return Palette.evening
        }
    }
}

// MARK: - 背景兼容（iOS 16 用 background，iOS 17+ 用 containerBackground）

extension View {
    @ViewBuilder
    func widgetBackground(_ color: Color) -> some View {
        if #available(iOSApplicationExtension 17.0, *) {
            containerBackground(color, for: .widget)
        } else {
            background(color)
        }
    }
}

// MARK: - 入口

@main
struct TimeTodoWidget: Widget {
    private let kind = "TimeTodoPeriodWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PeriodProvider()) { entry in
            PeriodWidgetView(entry: entry)
        }
        .configurationDisplayName("今日三段")
        .description("上午 / 下午 / 晚上，按 21:40、11:40、17:40 自动切换。")
        .supportedFamilies([.systemMedium, .systemLarge])
    }
}
