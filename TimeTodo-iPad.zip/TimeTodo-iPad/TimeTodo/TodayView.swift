import SwiftUI

/// 「今日待办」：上午 / 下午 / 晚上 三张大卡片，输入即自动保存。
/// 当前时段会有高亮边框，30 秒刷新一次，跨过 11:40 / 17:40 / 21:40 时自动跟着变。
struct TodayView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.horizontalSizeClass) private var sizeClass

    @State private var now = Date()
    @State private var ticker = Timer.publish(every: 30, on: .main, in: .common).autoconnect()

    private var currentPeriod: TimePeriod { TimeRule.period(for: now) }
    private var today: Date { TimeRule.effectiveDay(now: now) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header

                if sizeClass == .compact {
                    VStack(spacing: 16) {
                        cards
                    }
                } else {
                    HStack(alignment: .top, spacing: 16) {
                        cards
                    }
                }

                futureCard

                Text("每天 21:40 起显示次日；11:40 进入下午，17:40 进入晚上。")
                    .font(.system(size: 12))
                    .foregroundColor(Palette.secondary)
                    .padding(.leading, 4)
            }
            .padding(20)
        }
        .background(Palette.background.ignoresSafeArea())
        .navigationTitle("今日待办")
        .onReceive(ticker) { value in
            now = value
        }
    }

    // MARK: - 头部

    private var header: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(CalendarMath.dayTitle(today))
                    .font(.system(size: 26, weight: .bold))
                    .foregroundColor(Palette.title)
                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundColor(Palette.secondary)
            }
            Spacer(minLength: 8)
            HStack(spacing: 6) {
                Image(systemName: currentPeriod.symbol)
                    .font(.system(size: 12, weight: .semibold))
                Text(currentPeriod.displayName)
                    .font(.system(size: 13, weight: .semibold))
            }
            .foregroundColor(currentPeriod.tint)
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(currentPeriod.tint.opacity(0.12))
            .clipShape(Capsule())
        }
    }

    private var subtitle: String {
        let m = TimeRule.minutes(of: now)
        let clock = String(format: "%02d:%02d", m / 60, m % 60)
        let target: String
        let remaining: Int
        if m < TimeRule.afternoonStart {
            target = "下午"; remaining = TimeRule.afternoonStart - m
        } else if m < TimeRule.eveningStart {
            target = "晚上"; remaining = TimeRule.eveningStart - m
        } else if m < TimeRule.daySwitch {
            target = "次日"; remaining = TimeRule.daySwitch - m
        } else {
            target = "下午"; remaining = 24 * 60 - m + TimeRule.afternoonStart
        }
        let h = remaining / 60
        let mm = remaining % 60
        let left = h > 0 ? "\(h) 小时 \(mm) 分" : "\(mm) 分钟"
        return "现在 \(clock) · 距「\(target)」还有 \(left)"
    }

    // MARK: - 三张卡片

    @ViewBuilder
    private var cards: some View {
        ForEach(TimePeriod.allCases) { period in
            PeriodCard(period: period, isCurrent: period == currentPeriod)
                .frame(maxWidth: .infinity, alignment: .top)
        }
    }

    // MARK: - 未来待办

    private var futureCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(Palette.appointment)
                Text("未来待办")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Palette.appointment)
                Text("不随时段切换")
                    .font(.system(size: 12))
                    .foregroundColor(Palette.secondary)
                Spacer()
            }
            ZStack(alignment: .topLeading) {
                if store.futureText.isEmpty {
                    Text("在此输入预约文字待办…")
                        .font(.system(size: 15))
                        .foregroundColor(Palette.secondary.opacity(0.8))
                        .padding(.top, 8)
                        .padding(.leading, 5)
                }
                TextEditor(text: Binding(
                    get: { store.futureText },
                    set: { store.setFutureText($0) }
                ))
                .font(.system(size: 16))
                .lineSpacing(4)
                .scrollContentBackground(.hidden)
                .frame(minHeight: 96)
            }
        }
        .card()
    }
}

// MARK: - 单张时段卡片

private struct PeriodCard: View {
    let period: TimePeriod
    let isCurrent: Bool

    @EnvironmentObject private var store: Store
    @State private var showHandwriting = false

    private var text: Binding<String> {
        Binding(
            get: { store.text(for: period) },
            set: { store.setText($0, for: period) }
        )
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 7) {
                Image(systemName: period.symbol)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(period.tint)
                Text(period.displayName)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(period.tint)
                Text(period.timeRange)
                    .font(.system(size: 11.5, design: .rounded))
                    .foregroundColor(Palette.secondary)
                Spacer(minLength: 4)

                // 手写入口：和小组件点进来的是同一个页面
                Button {
                    showHandwriting = true
                } label: {
                    Image(systemName: "pencil.tip")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Palette.secondary)
                        .padding(4)
                }
                .buttonStyle(.plain)

                if isCurrent {
                    Text("当前")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .background(period.tint)
                        .clipShape(Capsule())
                }
            }

            RoundedRectangle(cornerRadius: 2)
                .fill(period.tint)
                .frame(height: 3)

            ZStack(alignment: .topLeading) {
                if text.wrappedValue.isEmpty {
                    Text(period.placeholder)
                        .font(.system(size: 15))
                        .foregroundColor(Palette.secondary.opacity(0.75))
                        .padding(.top, 8)
                        .padding(.leading, 5)
                }
                TextEditor(text: text)
                    .font(.system(size: 16))
                    .lineSpacing(5)
                    .scrollContentBackground(.hidden)
                    .frame(minHeight: 168)
            }

            HStack {
                Text(text.wrappedValue.isEmpty
                     ? "暂无内容，输入即自动保存"
                     : "已保存 · \(text.wrappedValue.count) 字")
                    .font(.system(size: 11.5))
                    .foregroundColor(Palette.secondary)
                Spacer()
            }
        }
        .card()
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(isCurrent ? period.tint.opacity(0.55) : Color.clear,
                        lineWidth: 1.5)
        )
        .sheet(isPresented: $showHandwriting) {
            HandwritingEditor(day: TimeRule.effectiveDay(), period: period)
                .environmentObject(store)
        }
    }
}
