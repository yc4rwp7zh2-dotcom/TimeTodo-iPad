import SwiftUI

/// 「日历预约」：左边月历，右边当天的 上午 / 下午 / 晚上。
/// 某天某时段只要写过文字，就以「文本式」呈现；否则是该时段的任务列表。
struct AppointmentView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.horizontalSizeClass) private var sizeClass

    @State private var month: Date = CalendarMath.startOfMonth(TimeRule.effectiveDay())
    @State private var selectedDay: Date = TimeRule.effectiveDay()
    @State private var editingItem: AppointmentItem?
    @State private var editingIsNew: Bool = false
    @State private var textContext: TextEditContext?
    @State private var now = Date()
    @State private var ticker = Timer.publish(every: 30, on: .main, in: .common).autoconnect()

    private var today: Date { TimeRule.effectiveDay(now: now) }

    var body: some View {
        ScrollView {
            if sizeClass == .compact {
                VStack(spacing: 16) {
                    calendarCard
                    detailCard
                }
                .padding(16)
            } else {
                HStack(alignment: .top, spacing: 16) {
                    calendarCard
                        .frame(width: 352)
                    detailCard
                }
                .padding(20)
            }
        }
        .background(Palette.background.ignoresSafeArea())
        .navigationTitle("日历预约")
        .onReceive(ticker) { value in
            now = value
        }
        .sheet(item: $editingItem) { item in
            AppointmentEditorView(item: item, isNew: editingIsNew) { saved in
                store.upsert(saved)
            }
        }
        .sheet(item: $textContext) { ctx in
            DayTextEditorView(day: ctx.day, period: ctx.period)
        }
    }

    // MARK: - 月历

    private var calendarCard: some View {
        VStack(spacing: 14) {
            HStack(spacing: 6) {
                Text("\(CalendarMath.year(of: month)) 年 \(CalendarMath.month(of: month)) 月")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Palette.title)
                Spacer(minLength: 4)
                iconButton("chevron.left") { shiftMonth(-1) }
                iconButton("chevron.right") { shiftMonth(1) }
                Text("今天")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(Palette.accent)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(Palette.accent.opacity(0.1))
                    .clipShape(Capsule())
                    .onTapGesture {
                        let day = TimeRule.effectiveDay()
                        selectedDay = day
                        month = CalendarMath.startOfMonth(day)
                    }
            }

            HStack(spacing: 0) {
                ForEach(CalendarMath.weekdayNames, id: \.self) { name in
                    Text(name)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(Palette.secondary)
                        .frame(maxWidth: .infinity)
                }
            }

            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 2), count: 7),
                      spacing: 2) {
                ForEach(monthDays.indices, id: \.self) { index in
                    dayCell(monthDays[index])
                }
            }
        }
        .card()
    }

    private var monthDays: [Date?] {
        let first = CalendarMath.startOfMonth(month)
        let leading = CalendarMath.isoWeekday(first) - 1
        let count = CalendarMath.daysInMonth(first)
        var result: [Date?] = Array(repeating: nil, count: leading)
        for index in 0..<count {
            let day = Calendar.current.date(byAdding: .day, value: index, to: first)
            result.append(day)
        }
        while result.count % 7 != 0 { result.append(nil) }
        return result
    }

    @ViewBuilder
    private func dayCell(_ day: Date?) -> some View {
        if let day = day {
            let isSelected = Calendar.current.isDate(day, inSameDayAs: selectedDay)
            let isToday = Calendar.current.isDate(day, inSameDayAs: today)
            let dots = store.dots(day: day)
            let visibleDots = Array(dots.prefix(3))
            VStack(spacing: 3) {
                Text("\(CalendarMath.day(of: day))")
                    .font(.system(size: 14, weight: isSelected || isToday ? .semibold : .regular))
                    .foregroundColor(isSelected ? .white : (isToday ? Palette.accent : Palette.body))
                HStack(spacing: 2) {
                    ForEach(visibleDots.indices, id: \.self) { index in
                        Circle()
                            .fill(isSelected ? Color.white.opacity(0.9) : dotColor(visibleDots[index]))
                            .frame(width: 4.5, height: 4.5)
                    }
                }
                .frame(height: 6)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(isSelected ? Palette.accent
                          : (isToday ? Palette.todayTint : Color.clear))
            )
            .contentShape(Rectangle())
            .onTapGesture {
                selectedDay = day
                if CalendarMath.monthsBetween(month, day) != 0 {
                    month = CalendarMath.startOfMonth(day)
                }
            }
        } else {
            Color.clear.frame(height: 44)
        }
    }

    private func dotColor(_ dot: DayDot) -> Color {
        switch dot {
        case .allDay: return Palette.appointment
        case .period(let period): return period.tint
        }
    }

    private func iconButton(_ symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(Palette.body)
                .frame(width: 26, height: 26)
                .background(Palette.background)
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }

    private func shiftMonth(_ delta: Int) {
        if let next = Calendar.current.date(byAdding: .month, value: delta, to: month) {
            month = CalendarMath.startOfMonth(next)
        }
    }

    // MARK: - 当天详情

    private var detailCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(CalendarMath.dayTitle(selectedDay))
                        .font(.system(size: 21, weight: .bold))
                        .foregroundColor(Palette.title)
                    let rel = CalendarMath.relativeName(selectedDay, now: now)
                    Text(rel.isEmpty ? "共 \(store.appointments(day: selectedDay).count) 项安排"
                                     : "\(rel) · 共 \(store.appointments(day: selectedDay).count) 项安排")
                        .font(.system(size: 12))
                        .foregroundColor(Palette.secondary)
                }
                Spacer(minLength: 8)
                Menu {
                    Button("全天事项") { addItem(allDay: true, period: nil) }
                    ForEach(TimePeriod.allCases) { period in
                        Button("\(period.displayName)（\(period.timeRange)）") {
                            addItem(allDay: false, period: period)
                        }
                    }
                } label: {
                    Label("添加", systemImage: "plus")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(Palette.accent)
                        .clipShape(Capsule())
                }
            }

            allDaySection

            ForEach(TimePeriod.allCases) { period in
                periodSection(period)
            }
        }
        .card(padding: 18)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    @ViewBuilder
    private var allDaySection: some View {
        let items = store.items(day: selectedDay, period: nil)
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 7) {
                    Circle().fill(Palette.appointment).frame(width: 8, height: 8)
                    Text("全天")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(Palette.appointment)
                    Text("不随时段切换")
                        .font(.system(size: 12))
                        .foregroundColor(Palette.secondary)
                    Spacer()
                }
                ForEach(items) { item in
                    itemRow(item)
                }
                Divider().background(Palette.hairline)
            }
        }
    }

    private func periodSection(_ period: TimePeriod) -> some View {
        let items = store.items(day: selectedDay, period: period)
        let text = store.dayText(day: selectedDay, period: period)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                PeriodHeader(period: period)
                Button {
                    textContext = TextEditContext(day: selectedDay, period: period)
                } label: {
                    Image(systemName: text.isEmpty ? "text.alignleft" : "square.and.pencil")
                        .font(.system(size: 13))
                        .foregroundColor(Palette.secondary)
                }
                .buttonStyle(.plain)
                Button {
                    addItem(allDay: false, period: period)
                } label: {
                    Image(systemName: "plus.circle")
                        .font(.system(size: 14))
                        .foregroundColor(period.tint)
                }
                .buttonStyle(.plain)
            }

            if !text.isEmpty {
                Text(text)
                    .font(.system(size: 15.5))
                    .lineSpacing(5)
                    .foregroundColor(Palette.body)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(10)
                    .background(period.tint.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .contentShape(Rectangle())
                    .onTapGesture {
                        textContext = TextEditContext(day: selectedDay, period: period)
                    }
            }

            if text.isEmpty && items.isEmpty {
                Text("暂无安排")
                    .font(.system(size: 13))
                    .foregroundColor(Palette.secondary)
                    .padding(.leading, 2)
            }

            ForEach(items) { item in
                itemRow(item)
            }
        }
    }

    private func itemRow(_ item: AppointmentItem) -> some View {
        HStack(alignment: .top, spacing: 9) {
            Button {
                store.toggleDone(item: item.id)
            } label: {
                Image(systemName: item.done ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 16))
                    .foregroundColor(item.done ? Palette.secondary
                                     : (item.period?.tint ?? Palette.appointment))
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 2) {
                Text(item.displayText)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(item.done ? Palette.secondary : Palette.body)
                    .strikethrough(item.done, color: Palette.secondary)
                if !item.title.isEmpty && !item.text.isEmpty {
                    Text(item.text)
                        .font(.system(size: 13))
                        .foregroundColor(Palette.secondary)
                        .lineLimit(2)
                }
                Text(item.repeatSummary + (item.allDay ? " · \(item.stepFormat)" : ""))
                    .font(.system(size: 11))
                    .foregroundColor(Palette.secondary.opacity(0.9))
            }
            Spacer(minLength: 4)
            Button {
                editingIsNew = false
                editingItem = item
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 15))
                    .foregroundColor(Palette.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 2)
        .contentShape(Rectangle())
        .onTapGesture {
            editingIsNew = false
            editingItem = item
        }
    }

    private func addItem(allDay: Bool, period: TimePeriod?) {
        var item = AppointmentItem()
        item.allDay = allDay
        item.period = allDay ? nil : period
        item.startDate = selectedDay
        editingIsNew = true
        editingItem = item
    }
}

// MARK: - 文本式编辑

struct TextEditContext: Identifiable {
    let id = UUID()
    let day: Date
    let period: TimePeriod
}

private struct DayTextEditorView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss

    let day: Date
    let period: TimePeriod

    @State private var text: String = ""

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 12) {
                PeriodHeader(period: period, trailing: CalendarMath.dayTitle(day))
                TextEditor(text: $text)
                    .font(.system(size: 16))
                    .lineSpacing(5)
                    .padding(10)
                    .background(Palette.background)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .padding(18)
            .navigationTitle("编辑文字")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        store.setDayText(text, day: day, period: period)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
            .onAppear {
                text = store.dayText(day: day, period: period)
            }
        }
    }
}

// MARK: - 预约编辑

struct AppointmentEditorView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss

    let isNew: Bool
    let onSave: (AppointmentItem) -> Void

    @State private var draft: AppointmentItem

    init(item: AppointmentItem, isNew: Bool, onSave: @escaping (AppointmentItem) -> Void) {
        self.isNew = isNew
        self.onSave = onSave
        _draft = State(initialValue: item)
    }

    private struct ReminderOption: Identifiable {
        let id: Int
        let title: String
    }

    private let reminderOptions: [ReminderOption] = [
        ReminderOption(id: -1, title: "不提醒"),
        ReminderOption(id: 0, title: "准时"),
        ReminderOption(id: 5, title: "提前 5 分钟"),
        ReminderOption(id: 10, title: "提前 10 分钟"),
        ReminderOption(id: 30, title: "提前 30 分钟"),
        ReminderOption(id: 60, title: "提前 1 小时")
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("内容") {
                    TextField("短标题（可留空）", text: $draft.title)
                    ZStack(alignment: .topLeading) {
                        if draft.text.isEmpty {
                            Text("具体内容…")
                                .foregroundColor(Palette.secondary.opacity(0.7))
                                .padding(.top, 8)
                                .padding(.leading, 5)
                        }
                        TextEditor(text: $draft.text)
                            .frame(minHeight: 84)
                    }
                }

                Section("时间") {
                    Toggle("全天", isOn: $draft.allDay)
                    if draft.allDay {
                        DatePicker("日期", selection: $draft.startDate,
                                   displayedComponents: .date)
                    } else {
                        Picker("时段", selection: Binding(
                            get: { draft.period ?? .morning },
                            set: { draft.period = $0 }
                        )) {
                            ForEach(TimePeriod.allCases) { period in
                                Text("\(period.displayName)（\(period.timeRange)）")
                                    .tag(period)
                            }
                        }
                        .pickerStyle(.segmented)
                        DatePicker("日期", selection: $draft.startDate,
                                   displayedComponents: .date)
                    }
                }

                Section("重复") {
                    Picker("方式", selection: $draft.repeatType) {
                        ForEach(RepeatType.allCases) { type in
                            Text(type.title).tag(type)
                        }
                    }

                    if draft.repeatType != .none {
                        Stepper(value: $draft.repeatInterval, in: 1...99) {
                            Text("间隔：每 \(draft.repeatInterval) "
                                 + unitName + "一次")
                        }

                        if draft.repeatType == .weekly {
                            weekdayPicker
                        }

                        if draft.repeatType == .monthly {
                            Picker("每月方式", selection: $draft.monthlyMode) {
                                Text("按日期").tag(MonthlyMode.day)
                                Text("按第几个星期").tag(MonthlyMode.nthWeekday)
                            }
                            .pickerStyle(.segmented)

                            if draft.monthlyMode == .day {
                                Stepper(value: Binding(
                                    get: { max(1, min(31, draft.monthlyDay == 0 ? CalendarMath.day(of: draft.startDate) : draft.monthlyDay)) },
                                    set: { draft.monthlyDay = $0 }
                                ), in: 1...31) {
                                    Text("每月 \(anchorDay) 日")
                                }
                            } else {
                                Stepper(value: $draft.monthlyNth, in: 1...4) {
                                    Text("第 \(draft.monthlyNth) 个")
                                }
                                Picker("星期", selection: $draft.monthlyNthWeekday) {
                                    ForEach(1...7, id: \.self) { index in
                                        Text("周" + CalendarMath.weekdayNames[index - 1])
                                            .tag(index)
                                    }
                                }
                            }
                        }

                        Picker("结束", selection: $draft.endMode) {
                            Text("永不").tag(AppointmentItem.RepeatEndMode.forever)
                            Text("到某日").tag(AppointmentItem.RepeatEndMode.untilDate)
                        }
                        if draft.endMode == .untilDate {
                            DatePicker("截止日期", selection: Binding(
                                get: { draft.repeatEndDate ?? draft.startDate },
                                set: { draft.repeatEndDate = $0 }
                            ), displayedComponents: .date)
                        }
                    }
                }

                Section("提醒") {
                    Picker("提醒", selection: $draft.reminderMinutes) {
                        ForEach(reminderOptions) { option in
                            Text(option.title).tag(option.id)
                        }
                    }
                }

                if !isNew {
                    Section {
                        Button("删除这一条", role: .destructive) {
                            store.delete(item: draft.id)
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle(isNew ? "新建预约" : "编辑预约")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        if draft.allDay { draft.period = nil }
                        if draft.repeatType == .none {
                            draft.weeklyDays = []
                        }
                        onSave(draft)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }

    private var anchorDay: Int {
        draft.monthlyDay >= 1 ? draft.monthlyDay : CalendarMath.day(of: draft.startDate)
    }

    private var unitName: String {
        switch draft.repeatType {
        case .daily: return "天"
        case .weekly: return "周"
        case .monthly: return "月"
        case .yearly: return "年"
        case .none: return "天"
        }
    }

    private var weekdayPicker: some View {
        HStack(spacing: 6) {
            ForEach(1...7, id: \.self) { index in
                let selected = draft.weeklyDays.contains(index)
                Text(CalendarMath.weekdayNames[index - 1])
                    .font(.system(size: 13, weight: selected ? .semibold : .regular))
                    .foregroundColor(selected ? .white : Palette.body)
                    .frame(width: 34, height: 30)
                    .background(selected ? Palette.accent : Palette.background)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    .onTapGesture {
                        if selected {
                            draft.weeklyDays.removeAll { $0 == index }
                        } else {
                            draft.weeklyDays.append(index)
                        }
                    }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
