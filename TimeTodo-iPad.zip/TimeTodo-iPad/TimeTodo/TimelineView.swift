import SwiftUI

/// 「时间轴」：竖线 + 节点，每条任务一种颜色。
/// 节点上下成串、标签左右交替，和安卓版的绘制方式一致。
struct TimelineView: View {
    @EnvironmentObject private var store: Store

    @State private var editingTask: TimelineTask?
    @State private var isNewTask = false
    @State private var now = Date()
    @State private var ticker = Timer.publish(every: 60, on: .main, in: .common).autoconnect()

    private var today: Date { TimeRule.effectiveDay(now: now) }

    var body: some View {
        let metrics = TimelineMetrics(tasks: store.tasks, today: today)

        ScrollView(.vertical) {
            GeometryReader { geo in
                Canvas { context, size in
                    draw(context: &context, size: size, metrics: metrics)
                }
                .frame(width: geo.size.width, height: metrics.contentHeight)
                .background(Palette.card)
                .contentShape(Rectangle())
                .gesture(
                    SpatialTapGesture()
                        .onEnded { value in
                            if let task = metrics.task(near: value.location,
                                                       tasks: store.tasks,
                                                       width: geo.size.width) {
                                isNewTask = false
                                editingTask = task
                            }
                        }
                )
            }
            .frame(height: metrics.contentHeight)
        }
        .background(Palette.background.ignoresSafeArea())
        .navigationTitle("时间轴")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    var task = TimelineTask()
                    task.name = "新任务"
                    task.colorHex = store.nextTaskColor()
                    task.nodes = [TimelineNode(date: today, label: "")]
                    isNewTask = true
                    editingTask = task
                } label: {
                    Label("新任务", systemImage: "plus")
                }
            }
        }
        .onReceive(ticker) { value in
            now = value
        }
        .sheet(item: $editingTask) { task in
            TimelineTaskEditorView(task: task, isNew: isNewTask) { saved in
                store.upsertTask(saved)
            }
        }
    }

    // MARK: - 绘制

    private func draw(context: inout GraphicsContext, size: CGSize, metrics: TimelineMetrics) {
        let width = size.width
        let centerX = width / 2
        let calendar = Calendar.current

        if store.tasks.isEmpty {
            context.draw(
                Text("暂无预约任务，点右上角「＋」新建")
                    .font(.system(size: 13))
                    .foregroundColor(Palette.secondary),
                at: CGPoint(x: centerX, y: metrics.y(today)),
                anchor: .center
            )
            return
        }

        // 中线
        var spine = Path()
        spine.move(to: CGPoint(x: centerX, y: metrics.topPad - 14))
        spine.addLine(to: CGPoint(x: centerX, y: metrics.contentHeight - metrics.bottomPad + 14))
        context.stroke(spine, with: .color(Palette.hairline), lineWidth: 1.5)

        // 月份分隔线
        let lastDay = calendar.date(byAdding: .day, value: metrics.dayCount - 1,
                                    to: metrics.startDay) ?? metrics.startDay
        var cursor = CalendarMath.startOfMonth(metrics.startDay)
        var guardCount = 0
        while cursor <= lastDay && guardCount < 400 {
            guardCount += 1
            if cursor >= metrics.startDay {
                let y = metrics.y(cursor)
                var line = Path()
                line.move(to: CGPoint(x: 12, y: y))
                line.addLine(to: CGPoint(x: width - 12, y: y))
                context.stroke(line,
                               with: .color(Palette.hairline.opacity(0.8)),
                               style: StrokeStyle(lineWidth: 1, dash: [3, 4]))
                context.draw(
                    Text("\(CalendarMath.month(of: cursor)) 月")
                        .font(.system(size: 10))
                        .foregroundColor(Palette.secondary),
                    at: CGPoint(x: centerX + 10, y: y - 8),
                    anchor: .leading
                )
            }
            cursor = calendar.date(byAdding: .month, value: 1, to: cursor) ?? lastDay
        }

        // 今天
        let todayY = metrics.y(today)
        var todayLine = Path()
        todayLine.move(to: CGPoint(x: 10, y: todayY))
        todayLine.addLine(to: CGPoint(x: width - 10, y: todayY))
        context.stroke(todayLine,
                       with: .color(Palette.accent.opacity(0.6)),
                       style: StrokeStyle(lineWidth: 1.2, dash: [5, 4]))
        context.draw(
            Text("今天")
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(Palette.accent),
            at: CGPoint(x: 12, y: todayY - 9),
            anchor: .leading
        )

        // 任务
        for task in store.tasks {
            let nodes = task.nodes.sorted { $0.date < $1.date }
            guard !nodes.isEmpty else { continue }
            let color = Color(hex: task.colorHex)

            if nodes.count > 1 {
                for index in 0..<(nodes.count - 1) {
                    var segment = Path()
                    segment.move(to: CGPoint(x: centerX, y: metrics.y(nodes[index].date)))
                    segment.addLine(to: CGPoint(x: centerX, y: metrics.y(nodes[index + 1].date)))
                    context.stroke(segment, with: .color(color.opacity(0.3)), lineWidth: 5)
                }
            }

            for (index, node) in nodes.enumerated() {
                let y = metrics.y(node.date)
                let radius: CGFloat = 6
                let dot = Path(ellipseIn: CGRect(x: centerX - radius,
                                                 y: y - radius,
                                                 width: radius * 2,
                                                 height: radius * 2))
                context.fill(dot, with: .color(color))
                context.stroke(dot, with: .color(.white), lineWidth: 1.5)

                let onRight = index % 2 == 0
                let labelX = onRight ? centerX + 16 : centerX - 16
                let anchor: UnitPoint = onRight ? .leading : .trailing

                if metrics.rowHeight >= 14, !node.label.isEmpty {
                    context.draw(
                        Text(truncated(node.label, limit: 14))
                            .font(.system(size: 12.5, weight: .medium))
                            .foregroundColor(Palette.body),
                        at: CGPoint(x: labelX, y: y - 7),
                        anchor: anchor
                    )
                    context.draw(
                        Text("\(CalendarMath.month(of: node.date))/\(CalendarMath.day(of: node.date)) (\(CalendarMath.isoWeekday(node.date)))")
                            .font(.system(size: 9.5))
                            .foregroundColor(Palette.secondary),
                        at: CGPoint(x: labelX, y: y + 8),
                        anchor: anchor
                    )
                }

                if index == 0 {
                    context.draw(
                        Text(truncated(task.name, limit: 8))
                            .font(.system(size: 11.5, weight: .semibold))
                            .foregroundColor(color),
                        at: CGPoint(x: labelX, y: y - (metrics.rowHeight >= 14 ? 24 : 16)),
                        anchor: anchor
                    )
                }
            }
        }
    }

    private func truncated(_ text: String, limit: Int) -> String {
        text.count <= limit ? text : String(text.prefix(limit)) + "…"
    }
}

// MARK: - 布局

struct TimelineMetrics {
    let startDay: Date
    let dayCount: Int
    let rowHeight: CGFloat
    let topPad: CGFloat = 36
    let bottomPad: CGFloat = 34

    init(tasks: [TimelineTask], today: Date) {
        var dates: [Date] = [today]
        for task in tasks {
            for node in task.nodes { dates.append(node.date) }
        }
        let earliest = dates.min() ?? today
        let latest = dates.max() ?? today
        var start = Calendar.current.startOfDay(for: earliest)
        start = Calendar.current.date(byAdding: .day, value: -3, to: start) ?? start
        var end = Calendar.current.startOfDay(for: latest)
        end = Calendar.current.date(byAdding: .day, value: 3, to: end) ?? end

        let count = max(1, CalendarMath.daysBetween(start, end) + 1)
        self.startDay = start
        self.dayCount = count
        self.rowHeight = max(6, min(26, 2600 / CGFloat(count)))
    }

    var contentHeight: CGFloat {
        topPad + CGFloat(dayCount) * rowHeight + bottomPad
    }

    func y(_ date: Date) -> CGFloat {
        topPad + CGFloat(CalendarMath.daysBetween(startDay, date)) * rowHeight
    }

    /// 点哪儿最近，就打开那条任务。
    func task(near point: CGPoint, tasks: [TimelineTask], width: CGFloat) -> TimelineTask? {
        var best: (TimelineTask, CGFloat)?
        for task in tasks {
            for node in task.nodes {
                let distance = abs(y(node.date) - point.y)
                if distance < 16 {
                    if best == nil || distance < best!.1 {
                        best = (task, distance)
                    }
                }
            }
        }
        return best?.0
    }
}

// MARK: - 任务编辑

struct TimelineTaskEditorView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss

    let isNew: Bool
    let onSave: (TimelineTask) -> Void

    @State private var draft: TimelineTask

    init(task: TimelineTask, isNew: Bool, onSave: @escaping (TimelineTask) -> Void) {
        self.isNew = isNew
        self.onSave = onSave
        _draft = State(initialValue: task)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("任务") {
                    TextField("任务名称", text: $draft.name)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("颜色")
                            .font(.system(size: 13))
                            .foregroundColor(Palette.secondary)
                        HStack(spacing: 10) {
                            ForEach(Palette.taskPalette.indices, id: \.self) { index in
                                let hex = Palette.taskPalette[index]
                                Circle()
                                    .fill(Color(hex: hex))
                                    .frame(width: 26, height: 26)
                                    .overlay(
                                        Circle()
                                            .stroke(Color.white, lineWidth: draft.colorHex == hex ? 3 : 0)
                                    )
                                    .overlay(
                                        Circle()
                                            .stroke(Palette.hairline, lineWidth: 1)
                                    )
                                    .onTapGesture { draft.colorHex = hex }
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section("节点") {
                    ForEach($draft.nodes) { $node in
                        VStack(alignment: .leading, spacing: 4) {
                            DatePicker("日期", selection: $node.date, displayedComponents: .date)
                                .font(.system(size: 14))
                            TextField("短标签，例如：交稿", text: $node.label)
                                .font(.system(size: 14))
                        }
                        .padding(.vertical, 2)
                    }
                    .onDelete { offsets in
                        draft.nodes.remove(atOffsets: offsets)
                    }

                    Button {
                        draft.nodes.append(TimelineNode(date: Date(), label: ""))
                    } label: {
                        Label("添加节点", systemImage: "plus.circle")
                    }
                }

                if !isNew {
                    Section {
                        Button("删除这条任务", role: .destructive) {
                            store.deleteTask(draft.id)
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle(isNew ? "新建任务" : "编辑任务")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        var copy = draft
                        if copy.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            copy.name = "任务"
                        }
                        copy.sortNodes()
                        onSave(copy)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }
}
