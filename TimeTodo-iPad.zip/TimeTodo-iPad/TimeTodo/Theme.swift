import SwiftUI

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255.0,
            green: Double((hex >> 8) & 0xFF) / 255.0,
            blue: Double(hex & 0xFF) / 255.0,
            opacity: 1.0
        )
    }
}

/// 配色沿用安卓版：上午橙、下午绿、晚上紫、预约蓝。
enum Palette {
    static let morning = Color(hex: 0xFF9800)
    static let afternoon = Color(hex: 0x4CAF50)
    static let evening = Color(hex: 0x673AB7)
    static let appointment = Color(hex: 0x2196F3)

    static let todayTint = Color(hex: 0xD6E9FF)
    static let background = Color(hex: 0xF2F4F7)
    static let card = Color.white

    static let title = Color(hex: 0x1F2328)
    static let body = Color(hex: 0x42474E)
    static let secondary = Color(hex: 0x8A9099)
    static let hairline = Color(hex: 0xE4E7EC)

    static let accent = Color(hex: 0x2196F3)

    /// 时间轴任务配色（与安卓端 PALETTE 相同）
    static let taskPalette: [UInt32] = [
        0x8B0000, 0x00008B, 0x006400, 0x4B0082,
        0x8B4513, 0x008B8B, 0x8B008B, 0x2F4F4F
    ]

    static func taskColor(_ hex: UInt32) -> Color { Color(hex: hex) }
}

extension TimePeriod {
    var tint: Color {
        switch self {
        case .morning: return Palette.morning
        case .afternoon: return Palette.afternoon
        case .evening: return Palette.evening
        }
    }

    var symbol: String {
        switch self {
        case .morning: return "sunrise.fill"
        case .afternoon: return "sun.max.fill"
        case .evening: return "moon.stars.fill"
        }
    }
}

// MARK: - 卡片外观

struct CardModifier: ViewModifier {
    var padding: CGFloat = 16

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(Palette.card)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Palette.hairline, lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.035), radius: 12, x: 0, y: 5)
    }
}

extension View {
    func card(padding: CGFloat = 16) -> some View {
        modifier(CardModifier(padding: padding))
    }
}

// MARK: - 小控件

/// 时段色点 + 名称 + 时间范围 的小标题。
struct PeriodHeader: View {
    let period: TimePeriod
    var trailing: String? = nil

    var body: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(period.tint)
                .frame(width: 8, height: 8)
            Text(period.displayName)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(period.tint)
            Text(period.timeRange)
                .font(.system(size: 12, weight: .regular, design: .rounded))
                .foregroundColor(Palette.secondary)
            Spacer(minLength: 0)
            if let trailing {
                Text(trailing)
                    .font(.system(size: 12))
                    .foregroundColor(Palette.secondary)
            }
        }
    }
}

/// 空状态提示
struct EmptyHint: View {
    let text: String
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "sparkles")
                .font(.system(size: 12))
            Text(text)
                .font(.system(size: 13))
        }
        .foregroundColor(Palette.secondary)
    }
}
