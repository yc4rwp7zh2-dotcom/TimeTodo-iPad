import SwiftUI
import PencilKit
import WidgetKit

/// 从小组件点进来的手写请求。
struct InkRequest: Identifiable {
    let day: Date
    let period: TimePeriod
    var id: String { InkStore.key(day: day, period: period) }
}

// MARK: - 工具

/// 画布当前拿的是什么：笔 还是 橡皮。
enum InkTool: String, CaseIterable, Identifiable {
    case pen
    case eraser

    var id: String { rawValue }

    var title: String {
        switch self {
        case .pen: return "笔"
        case .eraser: return "橡皮"
        }
    }

    var symbol: String {
        switch self {
        case .pen: return "pencil.tip"
        case .eraser: return "eraser.fill"
        }
    }
}

// MARK: - 画布模型

/// 把 PKCanvasView 的笔画状态、以及撤销/重做历史桥接到 SwiftUI。
///
/// 注意：`drawing` 故意**不加 @Published** —— 书写过程中每一笔都会被回调，
/// 若每次都触发 SwiftUI 重绘，笔迹会拖沓。真正需要刷新界面的是
/// 「能不能撤销 / 画布空不空」这两个粗粒度状态。
final class InkCanvasModel: ObservableObject {
    /// 当前笔画（始终与 PKCanvasView 同步，但不驱动界面重绘）。
    var drawing = PKDrawing()

    @Published private(set) var canUndo = false
    @Published private(set) var canRedo = false
    @Published private(set) var isEmpty = true

    /// 每次撤销/重做/清空/加载自增，供 InkCanvas 判断要不要把 drawing 写回画布。
    private(set) var applyToken = 0

    var isApplyingHistory = false
    weak var canvasView: PKCanvasView?

    private var undoStack: [PKDrawing] = []
    private var redoStack: [PKDrawing] = []
    private let maxHistory = 40

    /// 落笔前记一份快照（记录的是「还没改」的状态）。
    func beginGesture(from current: PKDrawing) {
        guard !isApplyingHistory else { return }
        undoStack.append(current)
        if undoStack.count > maxHistory {
            undoStack.removeFirst(undoStack.count - maxHistory)
        }
        redoStack.removeAll()
        refreshFlags()
    }

    /// 手势结束：如果什么都没改（比如在空白处划了一下），把刚才那份快照丢掉。
    func endGesture(_ final: PKDrawing) {
        guard !isApplyingHistory else { return }
        if let top = undoStack.last, top == final {
            undoStack.removeLast()
        }
        refreshFlags()
    }

    /// 画布内容变化（书写/擦除的实时回调）。
    func syncFromCanvas(_ current: PKDrawing) {
        drawing = current
        let nowEmpty = current.strokes.isEmpty
        if isEmpty != nowEmpty {
            isEmpty = nowEmpty
        }
    }

    func undo() {
        guard let target = undoStack.popLast() else { return }
        redoStack.append(drawing)
        apply(target)
    }

    func redo() {
        guard let target = redoStack.popLast() else { return }
        undoStack.append(drawing)
        apply(target)
    }

    /// 清空也进历史：手滑点错能一键退回来。
    func clear() {
        guard !drawing.strokes.isEmpty else { return }
        undoStack.append(drawing)
        if undoStack.count > maxHistory {
            undoStack.removeFirst(undoStack.count - maxHistory)
        }
        redoStack.removeAll()
        apply(PKDrawing())
    }

    /// 进页面时加载上次的笔画，历史清空。
    func reset(to newDrawing: PKDrawing) {
        undoStack.removeAll()
        redoStack.removeAll()
        apply(newDrawing)
    }

    private func apply(_ target: PKDrawing) {
        isApplyingHistory = true
        drawing = target
        canvasView?.drawing = target
        isApplyingHistory = false
        applyToken &+= 1
        if isEmpty != target.strokes.isEmpty {
            isEmpty = target.strokes.isEmpty
        }
        refreshFlags()
    }

    private func refreshFlags() {
        canUndo = !undoStack.isEmpty
        canRedo = !redoStack.isEmpty
    }
}

// MARK: - PencilKit 画布

struct InkCanvas: UIViewRepresentable {
    @ObservedObject var model: InkCanvasModel
    var tool: InkTool
    var color: UIColor
    var lineWidth: CGFloat
    var eraserWidth: CGFloat

    func makeUIView(context: Context) -> PKCanvasView {
        let view = PKCanvasView()
        view.backgroundColor = .clear
        view.isOpaque = false
        view.isScrollEnabled = false
        // .anyInput = 手指和 Apple Pencil 都能写，不强制要求笔
        view.drawingPolicy = .anyInput
        view.delegate = context.coordinator
        view.drawing = model.drawing
        context.coordinator.appliedToken = model.applyToken
        model.canvasView = view
        context.coordinator.applyTool(to: view)
        return view
    }

    func updateUIView(_ view: PKCanvasView, context: Context) {
        context.coordinator.parent = self

        // 只有撤销/重做/清空/加载这类「外部写入」才回写画布，
        // 平时的书写不回写，免得和正在画的笔打架。
        if context.coordinator.appliedToken != model.applyToken {
            context.coordinator.appliedToken = model.applyToken
            if view.drawing != model.drawing {
                view.drawing = model.drawing
            }
        }

        context.coordinator.applyTool(to: view)
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, PKCanvasViewDelegate {
        var parent: InkCanvas
        var appliedToken = 0
        /// 上次真正写进 PKCanvasView 的工具参数，避免重复设 tool 打断正在画的笔。
        private var lastToolSignature = ""

        init(_ parent: InkCanvas) { self.parent = parent }

        func applyTool(to view: PKCanvasView) {
            let signature = "\(parent.tool.rawValue)|\(parent.color.description)|\(parent.lineWidth)|\(parent.eraserWidth)"
            guard signature != lastToolSignature else { return }
            lastToolSignature = signature

            switch parent.tool {
            case .pen:
                view.tool = PKInkingTool(.pen, color: parent.color, width: parent.lineWidth)
            case .eraser:
                // .vector = 划到哪里就把那一整笔擦掉（比位图擦除更稳，渲染成 PNG 也一定生效）
                view.tool = PKEraserTool(.vector, width: parent.eraserWidth)
            }
        }

        func canvasViewDidBeginUsingTool(_ canvasView: PKCanvasView) {
            parent.model.beginGesture(from: canvasView.drawing)
        }

        func canvasViewDidEndUsingTool(_ canvasView: PKCanvasView) {
            parent.model.endGesture(canvasView.drawing)
        }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            parent.model.syncFromCanvas(canvasView.drawing)
        }
    }
}

// MARK: - 手写编辑页

/// 手写页：底层用浅灰显示这一段已经打好的文字，上层是可写的画布。
/// 保存后把笔画渲染成**透明背景 PNG** 存进 App Group，
/// 小组件再把它叠在文字上层。
struct HandwritingEditor: View {
    let day: Date
    let period: TimePeriod

    @EnvironmentObject private var store: Store
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = InkCanvasModel()
    @State private var tool: InkTool = .pen
    @State private var color: Color = .black
    @State private var lineWidth: CGFloat = 4
    @State private var eraserWidth: CGFloat = 20

    /// 画布的逻辑像素比例，渲染 PNG 时用同一个比例，避免小组件里被拉变形。
    private let logicalWidth: CGFloat = 640
    private let logicalHeight: CGFloat = 200

    private let colors: [Color] = [.black, Color(hex: 0x1F4FD8), Color(hex: 0xD32F2F)]
    private let widths: [CGFloat] = [3, 5, 8]
    private let eraserWidths: [CGFloat] = [10, 20, 34]

    private var dayTitle: String {
        "\(CalendarMath.month(of: day))月\(CalendarMath.day(of: day))日 \(CalendarMath.weekdayName(day))"
    }

    private var typedText: String {
        store.dayText(day: day, period: period)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(tool == .eraser
                         ? "橡皮：划到哪一笔就把那一笔整笔擦掉，擦多了点上方 ↩︎ 退回。"
                         : "在下面的框里手写，墨迹会盖在这段文字上面。")
                        .font(.system(size: 13))
                        .foregroundColor(Palette.secondary)
                        .fixedSize(horizontal: false, vertical: true)

                    canvasCard
                    tools

                    Text("小组件上不能直接落笔（系统限制），所以采用「点小组件 → 在这里写 → 墨迹回到小组件」的方式。")
                        .font(.system(size: 11.5))
                        .foregroundColor(Palette.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(20)
            }
            .background(Palette.background.ignoresSafeArea())
            .navigationTitle("手写 · \(dayTitle) · \(period.displayName)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { save() }
                        .fontWeight(.semibold)
                }
            }
        }
        .onAppear(perform: loadExisting)
    }

    // MARK: 画布

    private var canvasCard: some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.white)

            Text(typedText.isEmpty ? "（这一段还没有打字内容）" : typedText)
                .font(.system(size: 13))
                .foregroundColor(Color.black.opacity(typedText.isEmpty ? 0.18 : 0.32))
                .padding(14)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

            InkCanvas(
                model: model,
                tool: tool,
                color: UIColor(color),
                lineWidth: lineWidth,
                eraserWidth: eraserWidth
            )
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .aspectRatio(logicalWidth / logicalHeight, contentMode: .fit)
        .frame(maxWidth: 760)
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(tool == .eraser ? Palette.accent.opacity(0.55) : Palette.hairline,
                        lineWidth: tool == .eraser ? 1.5 : 1)
        )
    }

    // MARK: 工具条

    private var tools: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                toolSwitch
                Spacer(minLength: 0)
                historyButtons
            }

            Rectangle()
                .fill(Palette.hairline)
                .frame(height: 1)

            if tool == .pen {
                HStack(spacing: 14) {
                    HStack(spacing: 10) {
                        ForEach(colors, id: \.self) { item in
                            Circle()
                                .fill(item)
                                .frame(width: 26, height: 26)
                                .overlay(
                                    Circle().stroke(Palette.accent, lineWidth: color == item ? 2.5 : 0)
                                )
                                .onTapGesture { color = item }
                        }
                    }

                    Rectangle()
                        .fill(Palette.hairline)
                        .frame(width: 1, height: 22)

                    HStack(spacing: 10) {
                        ForEach(widths, id: \.self) { width in
                            Circle()
                                .fill(Palette.title.opacity(0.65))
                                .frame(width: width + 8, height: width + 8)
                                .frame(width: 22, height: 22)
                                .overlay(
                                    Circle().stroke(Palette.accent, lineWidth: lineWidth == width ? 2.5 : 0)
                                )
                                .onTapGesture { lineWidth = width }
                        }
                    }

                    Spacer(minLength: 0)
                }
            } else {
                HStack(spacing: 12) {
                    Text("橡皮大小")
                        .font(.system(size: 12))
                        .foregroundColor(Palette.secondary)

                    ForEach(eraserWidths, id: \.self) { width in
                        eraserChip(width)
                    }

                    Spacer(minLength: 0)

                    Text("小号适合改单字，大号适合整行划掉")
                        .font(.system(size: 11))
                        .foregroundColor(Palette.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
            }
        }
        .padding(14)
        .background(Palette.card)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Palette.hairline, lineWidth: 1)
        )
    }

    private var toolSwitch: some View {
        HStack(spacing: 6) {
            ForEach(InkTool.allCases) { item in
                let selected = tool == item
                Button {
                    tool = item
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: item.symbol)
                            .font(.system(size: 12, weight: .semibold))
                        Text(item.title)
                            .font(.system(size: 13, weight: .semibold))
                    }
                    .padding(.horizontal, 13)
                    .padding(.vertical, 7)
                    .foregroundColor(selected ? .white : Palette.body)
                    .background(
                        Capsule(style: .continuous)
                            .fill(selected ? Palette.accent : Color(hex: 0xEDF0F4))
                    )
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var historyButtons: some View {
        HStack(spacing: 8) {
            iconButton("arrow.uturn.backward", enabled: model.canUndo) {
                model.undo()
            }
            iconButton("arrow.uturn.forward", enabled: model.canRedo) {
                model.redo()
            }
            Button {
                model.clear()
            } label: {
                Label("清空", systemImage: "trash")
                    .font(.system(size: 13))
            }
            .buttonStyle(.bordered)
            .tint(Palette.secondary)
            .disabled(model.isEmpty)
        }
    }

    private func iconButton(_ symbol: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 14, weight: .semibold))
                .frame(width: 34, height: 34)
        }
        .buttonStyle(.bordered)
        .tint(Palette.body)
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.45)
    }

    private func eraserChip(_ width: CGFloat) -> some View {
        let selected = eraserWidth == width
        return Button {
            eraserWidth = width
        } label: {
            ZStack {
                Circle()
                    .fill(Color(hex: 0xEDF0F4))
                    .frame(width: 34, height: 34)
                Circle()
                    .fill(Palette.title.opacity(0.55))
                    .frame(width: width * 0.5, height: width * 0.5)
            }
            .overlay(
                Circle()
                    .strokeBorder(Palette.accent, lineWidth: selected ? 2.5 : 0)
                    .frame(width: 34, height: 34)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: 读写

    private func loadExisting() {
        guard let data = InkStore.drawingData(day: day, period: period),
              let drawing = try? PKDrawing(data: data) else { return }
        model.reset(to: drawing)
    }

    private func save() {
        if model.drawing.strokes.isEmpty {
            InkStore.clear(day: day, period: period)
        } else {
            let size = model.canvasView?.bounds.size ?? CGSize(width: logicalWidth, height: logicalHeight)
            let rect = CGRect(origin: .zero, size: size)
            // scale = 2：够清晰，PNG 也只有几十 KB，小组件读起来没负担
            let image = model.drawing.image(from: rect, scale: 2)
            InkStore.saveImage(image, day: day, period: period)
            InkStore.saveDrawingData(model.drawing.dataRepresentation(), day: day, period: period)
        }
        WidgetCenter.shared.reloadAllTimelines()
        dismiss()
    }
}
