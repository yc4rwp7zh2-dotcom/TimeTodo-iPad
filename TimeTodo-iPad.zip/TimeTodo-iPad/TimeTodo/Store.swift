import Foundation
import Combine
import WidgetKit

/// 全部数据的唯一入口。数据存成一份 JSON，放在 App 的 Application Support 目录里。
///
/// 对应安卓版的三处存储：
/// - `TodoRepository`（三段文字待办）→ `periodTexts`
/// - `AppointmentTodoStore`（预约条目）→ `appointments`
/// - `FutureTaskStore`（时间轴任务）→ `tasks`
final class Store: ObservableObject {
    static let shared = Store()

    @Published private(set) var appointments: [AppointmentItem] = []
    @Published private(set) var tasks: [TimelineTask] = []
    @Published private(set) var periodTexts: [String: String] = [:]
    /// 某天某时段写的「文本式」内容：dayKey -> period.rawValue -> 正文
    @Published private(set) var dayTexts: [String: [String: String]] = [:]
    @Published private(set) var futureText: String = ""

    private struct Payload: Codable {
        var appointments: [AppointmentItem] = []
        var tasks: [TimelineTask] = []
        var periodTexts: [String: String] = [:]
        var dayTexts: [String: [String: String]] = [:]
        var futureText: String = ""
    }

    private let fileURL: URL
    private var saveWorkItem: DispatchWorkItem?
    private var isLoading = true

    private static var encoder: JSONEncoder {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }

    private static var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }

    private init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory,
                                            in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("TimeTodo", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir,
                                                 withIntermediateDirectories: true)
        self.fileURL = dir.appendingPathComponent("store.json")
        load()
        isLoading = false
        // 冷启动时补一次同步：装好后第一次打开就有内容可显示
        syncWidget()
    }

    // MARK: - 读写

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let payload = try? Store.decoder.decode(Payload.self, from: data) else {
            return
        }
        appointments = payload.appointments
        tasks = payload.tasks
        periodTexts = payload.periodTexts
        dayTexts = payload.dayTexts
        futureText = payload.futureText
    }

    private func scheduleSave() {
        guard !isLoading else { return }
        saveWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            self?.saveNow()
        }
        saveWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: item)
    }

    func saveNow() {
        let payload = Payload(appointments: appointments,
                              tasks: tasks,
                              periodTexts: periodTexts,
                              dayTexts: dayTexts,
                              futureText: futureText)
        guard let data = try? Store.encoder.encode(payload) else { return }
        try? data.write(to: fileURL, options: .atomic)
        syncWidget()
    }

    /// 把数据同步给桌面小组件（App Group 共享容器），并让它的时间线重画。
    ///
    /// 小组件拿到的是原始数据而不是「算好的结论」，这样它自己按
    /// 11:40 / 17:40 / 21:40 三个边界切换，不依赖 App 是否在运行。
    private func syncWidget() {
        let snapshot = WidgetData(appointments: appointments,
                                  dayTexts: dayTexts,
                                  periodTexts: periodTexts,
                                  updatedAt: Date())
        WidgetShared.write(snapshot)
        WidgetCenter.shared.reloadAllTimelines()
    }

    // MARK: - 三段文字待办

    func text(for period: TimePeriod) -> String {
        periodTexts[period.rawValue] ?? ""
    }

    func setText(_ value: String, for period: TimePeriod) {
        if value.isEmpty {
            periodTexts.removeValue(forKey: period.rawValue)
        } else {
            periodTexts[period.rawValue] = value
        }
        objectWillChange.send()
        scheduleSave()
    }

    func setFutureText(_ value: String) {
        futureText = value
        scheduleSave()
    }

    // MARK: - 某天某时段的「文本式」内容

    func dayText(day: Date, period: TimePeriod) -> String {
        dayTexts[DateKey.string(from: day)]?[period.rawValue] ?? ""
    }

    func setDayText(_ value: String, day: Date, period: TimePeriod) {
        let key = DateKey.string(from: day)
        var bucket = dayTexts[key] ?? [:]
        if value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            bucket.removeValue(forKey: period.rawValue)
        } else {
            bucket[period.rawValue] = value
        }
        if bucket.isEmpty {
            dayTexts.removeValue(forKey: key)
        } else {
            dayTexts[key] = bucket
        }
        objectWillChange.send()
        scheduleSave()
    }

    // MARK: - 预约条目

    func items(day: Date, period: TimePeriod?) -> [AppointmentItem] {
        appointments
            .filter { item in
                if period == nil {
                    guard item.allDay else { return false }
                } else {
                    guard !item.allDay, item.period == period else { return false }
                }
                return item.matches(day: day)
            }
            .sorted { lhs, rhs in
                if lhs.done != rhs.done { return !lhs.done }
                return lhs.displayText < rhs.displayText
            }
    }

    func appointments(day: Date) -> [AppointmentItem] {
        appointments.filter { $0.matches(day: day) }
    }

    /// 某天有哪些小圆点，用于日历格子。
    func dots(day: Date) -> [DayDot] {
        let list = appointments(day: day)
        var result: [DayDot] = []
        if list.contains(where: { $0.allDay }) { result.append(.allDay) }
        for period in TimePeriod.allCases {
            if list.contains(where: { !$0.allDay && $0.period == period }) {
                result.append(.period(period))
            }
        }
        // 只有「文本式」内容的日子也给一个小点，免得日历上看不出有内容
        if result.isEmpty {
            let key = DateKey.string(from: day)
            if let bucket = dayTexts[key], !bucket.isEmpty {
                result.append(.allDay)
            }
        }
        return result
    }

    func upsert(_ item: AppointmentItem) {
        if let index = appointments.firstIndex(where: { $0.id == item.id }) {
            appointments[index] = item
        } else {
            appointments.append(item)
        }
        scheduleSave()
    }

    func delete(item id: UUID) {
        appointments.removeAll { $0.id == id }
        scheduleSave()
    }

    func toggleDone(item id: UUID) {
        guard let index = appointments.firstIndex(where: { $0.id == id }) else { return }
        appointments[index].done.toggle()
        scheduleSave()
    }

    // MARK: - 时间轴

    func upsertTask(_ task: TimelineTask) {
        var copy = task
        copy.sortNodes()
        if let index = tasks.firstIndex(where: { $0.id == copy.id }) {
            tasks[index] = copy
        } else {
            tasks.append(copy)
        }
        scheduleSave()
    }

    func deleteTask(_ id: UUID) {
        tasks.removeAll { $0.id == id }
        scheduleSave()
    }

    func nextTaskColor() -> UInt32 {
        Palette.taskPalette[tasks.count % Palette.taskPalette.count]
    }
}
