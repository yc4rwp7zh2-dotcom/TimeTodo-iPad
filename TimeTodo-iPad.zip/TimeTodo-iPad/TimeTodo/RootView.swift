import SwiftUI

enum Route: String, CaseIterable, Identifiable {
    case today
    case appointment
    case timeline

    var id: String { rawValue }

    var title: String {
        switch self {
        case .today: return "今日待办"
        case .appointment: return "日历预约"
        case .timeline: return "时间轴"
        }
    }

    var icon: String {
        switch self {
        case .today: return "checkmark.circle"
        case .appointment: return "calendar"
        case .timeline: return "chart.bar.fill"
        }
    }
}

/// iPad 横屏用「侧边栏 + 主区」；竖屏或 iPhone 会自动收成可返回的栈。
struct RootView: View {
    @State private var route: Route? = .today
    @State private var inkRequest: InkRequest?

    var body: some View {
        NavigationSplitView {
            List(selection: $route) {
                Section {
                    ForEach(Route.allCases) { item in
                        Label(item.title, systemImage: item.icon)
                            .tag(item)
                    }
                } header: {
                    Text("TimeTodo")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(Palette.secondary)
                }
            }
            .listStyle(.sidebar)
            .navigationTitle("TimeTodo")
        } detail: {
            switch route ?? .today {
            case .today:
                TodayView()
            case .appointment:
                AppointmentView()
            case .timeline:
                TimelineView()
            }
        }
        .navigationSplitViewStyle(.balanced)
        // 小组件点「上午/下午/晚上」会带 timetodo://ink?day=…&period=… 打开 App
        .onOpenURL { url in
            guard let request = RootView.parseInkURL(url) else { return }
            inkRequest = request
        }
        .sheet(item: $inkRequest) { request in
            HandwritingEditor(day: request.day, period: request.period)
                .environmentObject(Store.shared)
        }
    }

    /// 解析小组件传来的手写深链。
    static func parseInkURL(_ url: URL) -> InkRequest? {
        guard url.scheme == "timetodo", url.host == "ink" else { return nil }
        let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let dayString = items.first(where: { $0.name == "day" })?.value
        let periodString = items.first(where: { $0.name == "period" })?.value

        let day = dayString.flatMap { DateKey.date(from: $0) } ?? TimeRule.effectiveDay()
        let period = periodString.flatMap { TimePeriod(rawValue: $0) } ?? TimeRule.period()
        return InkRequest(day: day, period: period)
    }
}
