import Foundation

// MARK: - 时段

/// 一天的三个时段。与安卓版 `TimePeriod` 一一对应。
///
/// 注意「上午」是个跨零点的时段：**前一天 21:40 → 当天 11:40**。
/// 但显示文案按用户要求在界面上写 `07:00 – 11:40`，两者不要混淆。
enum TimePeriod: String, CaseIterable, Identifiable, Codable {
    case morning
    case afternoon
    case evening

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .morning: return "上午"
        case .afternoon: return "下午"
        case .evening: return "晚上"
        }
    }

    /// 界面上显示的时间范围（上午按用户要求从 07:00 起写）。
    var timeRange: String {
        switch self {
        case .morning: return "07:00 – 11:40"
        case .afternoon: return "11:40 – 17:40"
        case .evening: return "17:40 – 21:40"
        }
    }

    /// 输入框为空时的灰色提示语。
    var placeholder: String {
        switch self {
        case .morning: return "早上好！今日上午待办"
        case .afternoon: return "下午好！今日下午待办"
        case .evening: return "晚上好！今日晚上待办"
        }
    }
}

// MARK: - 时间规则

/// 全 App 唯一的时段 / 跨天判定，避免各处各写一套。
///
/// - 11:40 起算「下午」
/// - 17:40 起算「晚上」
/// - 21:40 起算「次日」（此时 App 显示的是明天的上午）
enum TimeRule {
    static let afternoonStart = 11 * 60 + 40   // 11:40
    static let eveningStart   = 17 * 60 + 40   // 17:40
    static let daySwitch      = 21 * 60 + 40   // 21:40

    static func minutes(of date: Date, calendar: Calendar = .current) -> Int {
        let c = calendar.dateComponents([.hour, .minute], from: date)
        return (c.hour ?? 0) * 60 + (c.minute ?? 0)
    }

    /// 当前时刻属于哪个时段。21:40–24:00 与 00:00–11:40 同属「上午」。
    static func period(for date: Date = Date(), calendar: Calendar = .current) -> TimePeriod {
        let m = minutes(of: date, calendar: calendar)
        if m >= daySwitch || m < afternoonStart { return .morning }
        if m < eveningStart { return .afternoon }
        return .evening
    }

    /// 「现在算哪一天」——21:40 之后就算次日。
    static func effectiveDay(now: Date = Date(), calendar: Calendar = .current) -> Date {
        let start = calendar.startOfDay(for: now)
        if minutes(of: now, calendar: calendar) >= daySwitch {
            return calendar.date(byAdding: .day, value: 1, to: start) ?? start
        }
        return start
    }

    static func pastDaySwitch(now: Date = Date(), calendar: Calendar = .current) -> Bool {
        minutes(of: now, calendar: calendar) >= daySwitch
    }
}

// MARK: - 日期工具

enum DateKey {
    static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.calendar = Calendar(identifier: .gregorian)
        f.locale = Locale(identifier: "zh_CN")
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()

    static func string(from date: Date) -> String { formatter.string(from: date) }
    static func date(from key: String) -> Date? { formatter.date(from: key) }
}

enum CalendarMath {
    static var cal: Calendar { Calendar.current }

    static func day(of d: Date) -> Int { cal.component(.day, from: d) }
    static func month(of d: Date) -> Int { cal.component(.month, from: d) }
    static func year(of d: Date) -> Int { cal.component(.year, from: d) }

    /// 1 = 周一 … 7 = 周日（安卓端用的是 ISO 星期号，这里对齐）。
    static func isoWeekday(_ d: Date) -> Int {
        let w = cal.component(.weekday, from: d)   // 1 = 周日
        return ((w + 5) % 7) + 1
    }

    static func daysBetween(_ a: Date, _ b: Date) -> Int {
        let s = cal.startOfDay(for: a)
        let e = cal.startOfDay(for: b)
        return cal.dateComponents([.day], from: s, to: e).day ?? 0
    }

    static func monthsBetween(_ a: Date, _ b: Date) -> Int {
        (year(of: b) - year(of: a)) * 12 + (month(of: b) - month(of: a))
    }

    static func startOfMonth(_ d: Date) -> Date {
        let c = cal.dateComponents([.year, .month], from: d)
        return cal.date(from: c) ?? d
    }

    static func daysInMonth(_ d: Date) -> Int {
        cal.range(of: .day, in: .month, for: d)?.count ?? 30
    }

    /// 某月里第 nth 个「星期 weekday」是哪一天；超出时回退到该月最后一个同星期。
    static func nthWeekday(in anyDay: Date, nth: Int, weekday: Int) -> Date {
        let first = startOfMonth(anyDay)
        let firstIso = isoWeekday(first)
        let delta = (weekday - firstIso + 7) % 7
        let last = daysInMonth(first)
        var day = 1 + delta + (max(1, min(4, nth)) - 1) * 7
        if day > last {
            day = 1 + delta + ((last - (1 + delta)) / 7) * 7
        }
        day = min(max(1, day), last)
        return cal.date(byAdding: .day, value: day - 1, to: first) ?? first
    }

    /// 「每月 X 日」落在某月里的实际日期；该月没有这一天就落到月末。
    static func monthlyDay(in anyDay: Date, wanted: Int) -> Date {
        let first = startOfMonth(anyDay)
        let last = daysInMonth(first)
        let d = min(max(1, wanted), last)
        return cal.date(byAdding: .day, value: d - 1, to: first) ?? first
    }

    static let weekdayNames = ["一", "二", "三", "四", "五", "六", "日"]

    static func weekdayName(_ d: Date) -> String {
        "周" + weekdayNames[isoWeekday(d) - 1]
    }

    /// 「11月16日 周日」
    static func dayTitle(_ d: Date) -> String {
        "\(month(of: d))月\(day(of: d))日 \(weekdayName(d))"
    }

    /// 「今天」「明天」「昨天」，其余返回空串。
    static func relativeName(_ d: Date, now: Date = Date()) -> String {
        let today = TimeRule.effectiveDay(now: now)
        let gap = daysBetween(today, d)
        switch gap {
        case 0: return "今天"
        case 1: return "明天"
        case -1: return "昨天"
        default: return ""
        }
    }
}

/// 日历格子里的小圆点：全天用蓝色，其余用对应时段色。
enum DayDot: Hashable {
    case allDay
    case period(TimePeriod)
}

// MARK: - 重复规则

enum RepeatType: String, Codable, CaseIterable, Identifiable {
    case none, daily, weekly, monthly, yearly
    var id: String { rawValue }

    var title: String {
        switch self {
        case .none: return "不重复"
        case .daily: return "每天"
        case .weekly: return "每周"
        case .monthly: return "每月"
        case .yearly: return "每年"
        }
    }
}

enum MonthlyMode: String, Codable {
    case day        // 每月 X 日
    case nthWeekday // 每月第 N 个周 X
}

// MARK: - 预约条目

/// 一条预约。`allDay == true` 时 `period` 为空，表示「全天」。
struct AppointmentItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var text: String = ""
    var title: String = ""
    var allDay: Bool = true
    var period: TimePeriod? = nil
    var done: Bool = false
    var startDate: Date = Calendar.current.startOfDay(for: Date())
    var endDate: Date? = nil

    var repeatType: RepeatType = .none
    var repeatInterval: Int = 1
    var weeklyDays: [Int] = []          // 1 = 周一 … 7 = 周日
    var monthlyMode: MonthlyMode = .day
    var monthlyDay: Int = 0             // 0 = 用 startDate 的日号
    var monthlyNth: Int = 1             // 第几个
    var monthlyNthWeekday: Int = 1      // 周几

    var endMode: RepeatEndMode = .forever
    var repeatEndDate: Date? = nil
    var reminderMinutes: Int = -1       // -1 = 不提醒

    enum RepeatEndMode: String, Codable {
        case forever, untilDate
    }

    /// 列表里显示的主文本：标题优先，否则用正文首行。
    var displayText: String {
        if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return title }
        let firstLine = text.split(separator: "\n").first.map(String.init) ?? text
        return firstLine.isEmpty ? "（未命名）" : firstLine
    }

    /// 全天条目的步骤格式：26-11-16
    var stepFormat: String {
        let d = startDate
        return String(format: "%02d-%02d-%02d",
                      CalendarMath.year(of: d) % 100,
                      CalendarMath.month(of: d),
                      CalendarMath.day(of: d))
    }

    /// 是否落在某一天（含重复规则）。与安卓端 `TodoFilter.matchesDay` 同一套判定。
    func matches(day rawDay: Date) -> Bool {
        let day = Calendar.current.startOfDay(for: rawDay)
        let start = Calendar.current.startOfDay(for: startDate)
        let endRaw = Calendar.current.startOfDay(for: endDate ?? startDate)
        let end = max(endRaw, start)

        switch repeatType {
        case .none:
            return day >= start && day <= end

        case .daily, .weekly, .monthly, .yearly:
            if day < start { return false }
            if endMode == .untilDate, let limit = repeatEndDate,
               day > Calendar.current.startOfDay(for: limit) { return false }

            let interval = max(1, repeatInterval)
            switch repeatType {
            case .daily:
                let gap = CalendarMath.daysBetween(start, day)
                return gap >= 0 && gap % interval == 0

            case .weekly:
                let gap = CalendarMath.daysBetween(start, day)
                let dow = CalendarMath.isoWeekday(day)
                let selected = weeklyDays.isEmpty || weeklyDays.contains(dow)
                return selected && (gap / 7) % interval == 0

            case .monthly:
                if monthlyMode == .nthWeekday {
                    let target = CalendarMath.nthWeekday(in: day,
                                                         nth: monthlyNth,
                                                         weekday: monthlyNthWeekday)
                    guard Calendar.current.isDate(target, inSameDayAs: day) else { return false }
                } else {
                    let anchor = monthlyDay >= 1
                        ? monthlyDay
                        : CalendarMath.day(of: start)
                    let target = CalendarMath.monthlyDay(in: day, wanted: anchor)
                    guard Calendar.current.isDate(target, inSameDayAs: day) else { return false }
                }
                let months = CalendarMath.monthsBetween(start, day)
                return months >= 0 && months % interval == 0

            case .yearly:
                guard CalendarMath.month(of: day) == CalendarMath.month(of: start),
                      CalendarMath.day(of: day) == CalendarMath.day(of: start) else { return false }
                let years = CalendarMath.year(of: day) - CalendarMath.year(of: start)
                return years >= 0 && years % interval == 0

            case .none:
                return false
            }
        }
    }

    /// 规则的中文摘要，用于列表副标题。
    var repeatSummary: String {
        switch repeatType {
        case .none:
            if let e = endDate, CalendarMath.daysBetween(startDate, e) > 0 {
                return "\(CalendarMath.dayTitle(startDate)) 起至 \(CalendarMath.dayTitle(e))"
            }
            return "单次"
        case .daily:
            return repeatInterval > 1 ? "每 \(repeatInterval) 天" : "每天"
        case .weekly:
            let days = weeklyDays.sorted().map { CalendarMath.weekdayNames[$0 - 1] }.joined(separator: "、")
            let base = repeatInterval > 1 ? "每 \(repeatInterval) 周" : "每周"
            return days.isEmpty ? base : "\(base) \(days)"
        case .monthly:
            let base = repeatInterval > 1 ? "每 \(repeatInterval) 个月" : "每月"
            if monthlyMode == .nthWeekday {
                return "\(base)第 \(monthlyNth) 个周\(CalendarMath.weekdayNames[monthlyNthWeekday - 1])"
            }
            return "\(base) \(monthlyDay >= 1 ? monthlyDay : CalendarMath.day(of: startDate)) 日"
        case .yearly:
            return repeatInterval > 1 ? "每 \(repeatInterval) 年" : "每年"
        }
    }
}

// MARK: - 时间轴

struct TimelineNode: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var date: Date
    var label: String = ""
}

/// 时间轴上一个「任务」＝ 名称 + 颜色 + 若干节点（日期 + 短标签）。
struct TimelineTask: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String = "任务"
    var colorHex: UInt32 = 0x8B0000
    var nodes: [TimelineNode] = []

    var startDate: Date? { nodes.map(\.date).min() }
    var endDate: Date? { nodes.map(\.date).max() }

    mutating func sortNodes() {
        nodes.sort { $0.date < $1.date }
    }
}
